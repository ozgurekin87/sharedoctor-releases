# Install.ps1 - installs (or removes) Share Doctor for ALL users of this PC. Started by Install.bat / Uninstall.bat (administrator).
param([switch]$Uninstall)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
function Say([string]$text, [string]$buttons = 'OK') {
    return [System.Windows.Forms.MessageBox]::Show($text, 'Share Doctor', $buttons)
}

$Dest      = 'C:\ShareDoctor'
$StartLnk  = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\StartUp\Share Doctor.lnk'
$DeskLnk   = Join-Path $env:PUBLIC 'Desktop\Share Doctor.lnk'
$here      = Split-Path -Parent $MyInvocation.MyCommand.Path

function Stop-Running {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
        Where-Object { $_.CommandLine -like '*ShareDoctor.ps1*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}

try {
    if ($Uninstall) {
        $a = Say "Remove Share Doctor from this PC?`n`nThe blocking of other PCs that Share Doctor set up will be lifted. Your shared folders and files are not touched." 'YesNo'
        if ($a -ne 'Yes') { return }
        Stop-Running
        Unregister-ScheduledTask -TaskName 'ShareDoctor Guard' -Confirm:$false -ErrorAction SilentlyContinue
        Get-NetFirewallRule -Name 'ShareDoctor-BlockSMB' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
        Remove-Item $StartLnk, $DeskLnk -Force -ErrorAction SilentlyContinue
        Remove-Item $Dest -Recurse -Force -ErrorAction SilentlyContinue
        [void](Say 'Share Doctor was removed.')
        return
    }

    Stop-Running
    if (-not (Test-Path $Dest)) { New-Item -ItemType Directory -Path $Dest | Out-Null }
    Copy-Item (Join-Path $here 'ShareDoctor.ps1') $Dest -Force
    Copy-Item (Join-Path $here 'Launch.vbs') $Dest -Force
    Copy-Item (Join-Path $here 'ShareDoctor.ico') $Dest -Force

    # first install: write a starting settings file; the Settings window opens by itself to finish it
    $cfgPath = Join-Path $Dest 'config.json'
    if (-not (Test-Path $cfgPath)) {
        $cfg = [pscustomobject]@{
            Gateway        = '192.168.10.1'
            ExpectedSubnet = '192.168.10.'
            ShareUser      = ($env:COMPUTERNAME + '\countshare')
            UpdateSource   = 'https://raw.githubusercontent.com/ozgurekin87/sharedoctor-releases/main'
            CheckSeconds   = 60
            PopupOnFail    = $true
            EnforceAccess  = $true
            FirstRun       = $true
            Remotes        = @()
            LocalShares    = @()
            Printers       = @()
            AllowedPCs     = @()
        }
        $cfg | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $cfgPath -Encoding UTF8
    }

    # updating the shared-folder PC: the installer stopped the background repair task, so start it again
    if (Get-ScheduledTask -TaskName 'ShareDoctor Guard' -ErrorAction SilentlyContinue) { Start-ScheduledTask -TaskName 'ShareDoctor Guard' }

    # start with Windows for every user + desktop icon
    $wsh = New-Object -ComObject WScript.Shell
    foreach ($lnk in @($StartLnk, $DeskLnk)) {
        $dir = Split-Path $lnk -Parent
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $sc = $wsh.CreateShortcut($lnk)
        $sc.TargetPath = "$env:SystemRoot\System32\wscript.exe"
        $sc.Arguments = '"' + (Join-Path $Dest 'Launch.vbs') + '"'
        $sc.WorkingDirectory = $Dest
        $sc.IconLocation = (Join-Path $Dest 'ShareDoctor.ico')
        $sc.Description = 'Share Doctor - checks the shared folders'
        $sc.Save()
    }

    # open through Explorer so it runs as the normal signed-in user (not elevated)
    Start-Process explorer.exe -ArgumentList ('"' + $StartLnk + '"')
    [void](Say "Share Doctor is installed.`n`nIt starts with Windows. A Settings window opens now: fill in the details and click Save.")
}
catch {
    [void](Say ("Something went wrong:`n`n" + $_.Exception.Message))
}
