SHARE DOCTOR
============
A small program for every PC that uses the shared folders. Everything is done in windows and buttons:
no command line, no Notepad. It starts with Windows and sits near the clock as a coloured circle.

  green  = everything works
  yellow = works, but something needs attention (printers only ever make it yellow)
  red    = the shared folders are not reachable (a message pops up after 2 failed checks)

INSTALL (every PC - all PCs are equal, each one can share folders AND open folders from other PCs)
  1. Copy this whole folder to the PC (USB stick or network).
  2. Double-click Install.bat and say Yes to the permission question.
  3. The Settings window opens. Fill in the tabs that apply and click Save (asks permission once).
  To UPDATE later: copy the new folder over and run Install.bat again. Settings are kept.

AUTOMATIC DISCOVERY
  Once the sharing password is saved on a PC, Share Doctor looks for PCs on the casino network every 10 minutes,
  signs in with the sharing account, and adds every folder those PCs share with it. A PC only answers if this PC is
  in its "Who may connect" list. New folders appear in "Open folder" and are checked automatically.
  The password is stored encrypted for the signed-in Windows user only.

SETTINGS (button "Settings") - everything is done here, no Windows settings, no command line
  This PC            : router address, and ONE sharing password (use the same on every PC).
                       Share Doctor creates the sharing account "countshare" on this PC by itself.
  Folders I open     : click "Find PCs on the network" to pick PCs from a list (name and IP are filled in),
                       then type the folder name and an optional drive letter.
                       Share Doctor saves the login and maps the drive for you.
  Folders I share    : pick a folder on this PC and a name. Saving creates the share. Only the sharing
                       account can open it - not "Everyone".
  Who may connect    : the PCs allowed to open folders on THIS PC (name + IP) - also has "Find PCs". EVERY OTHER PC IS BLOCKED.
  Printers           : network printers to watch (name + IP).
  Give every PC a fixed IP in UniFi: blocking works by IP address.

WHAT IT CHECKS EVERY 60 SECONDS
  the casino network and router, the shared-folder PC (ping, name, file-sharing port), the saved login, each
  folder and drive letter, the blocking rule, network printers, and (on the shared-folder PC) network type,
  Server service, firewall, sleep, IP, and the automatic repair.

ONE-CLICK FIXES ("Fix all problems" / "Fix selected")
  re-enter the login, remap drives, pin the name to the IP, set the network to Private, stop the PC sleeping,
  start or restart file sharing, allow file sharing in the firewall, restart printing, block PCs that are not allowed.
  Anything that needs administrator permission asks once.

AUTOMATIC REPAIR (shared-folder PC only)
  A hidden background task checks file sharing every 30 seconds. If it is stuck for about 2 minutes it restarts the
  Windows file-sharing service by itself (no PC restart), then resets the network adapter if needed. At most 4
  tries an hour. Log: C:\ProgramData\ShareDoctor\guard.log. The window shows the last repair.

REMOVE
  Double-click Uninstall.bat. It also removes the blocking rule.
