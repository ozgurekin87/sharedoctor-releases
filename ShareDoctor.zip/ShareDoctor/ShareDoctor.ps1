# ShareDoctor.ps1 - Share Doctor, created by Ekin Ozgur (built with Claude Code)
# Watches the connection to the shared-folder PC, tells you when something breaks, and fixes the common causes.
# Normal Windows file sharing is still used underneath, so Excel/VBA files open from the mapped drives as before.

param(
    [string]$Fix = '',          # internal: run elevated fixes (comma separated) and exit
    [switch]$Guard,
    [switch]$Activity,          # internal: elevated 'who connected' viewer             # internal: background auto-repair on the shared-folder PC (runs as SYSTEM)
    [string]$Proposal = '',     # internal: new settings file to save (elevated)
    [string]$ConfigPath = '',
    [string]$Update = ''        # internal: elevated update, folder with the new files
)

$AppVersion = '5.8.1'

$ErrorActionPreference = 'Stop'
if (-not $ConfigPath) { $ConfigPath = Join-Path $PSScriptRoot 'config.json' }

# ---------------------------------------------------------------- config + log
function Read-Config {
    $c = Get-Content -LiteralPath $ConfigPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if (-not $c.CheckSeconds)    { $c | Add-Member -NotePropertyName CheckSeconds    -NotePropertyValue 60 -Force }
    if (-not $c.ExpectedSubnet)  { $c | Add-Member -NotePropertyName ExpectedSubnet  -NotePropertyValue '192.168.10.' -Force }
    if ($null -eq $c.PopupOnFail){ $c | Add-Member -NotePropertyName PopupOnFail    -NotePropertyValue $true -Force }
    if ($null -eq $c.Printers)   { $c | Add-Member -NotePropertyName Printers       -NotePropertyValue @() -Force }
    if ($null -eq $c.AllowedPCs) { $c | Add-Member -NotePropertyName AllowedPCs     -NotePropertyValue @() -Force }
    if ($null -eq $c.EnforceAccess) { $c | Add-Member -NotePropertyName EnforceAccess -NotePropertyValue $true -Force }
    if (-not $c.UpdateSource) { $c | Add-Member -NotePropertyName UpdateSource -NotePropertyValue 'https://raw.githubusercontent.com/ozgurekin87/sharedoctor-releases/main' -Force }
    if ($null -eq $c.AutoDiscover) { $c | Add-Member -NotePropertyName AutoDiscover -NotePropertyValue $true -Force }
    if ($null -eq $c.SharePwProtected) { $c | Add-Member -NotePropertyName SharePwProtected -NotePropertyValue '' -Force }
    if ($null -eq $c.FirstRun)   { $c | Add-Member -NotePropertyName FirstRun       -NotePropertyValue $false -Force }
    # older layout (one shared-folder PC): convert it
    if ($null -eq $c.Remotes -and $null -eq $c.LocalShares) {
        $remotes = @(); $local = @()
        if ($c.IsHost) {
            foreach ($sh in @($c.Shares)) { if ($sh.Path) { $local += [pscustomobject]@{ Share = [string]$sh.Share; Path = [string]$sh.Path } } }
        } elseif ($c.HostIP) {
            $list = @(); foreach ($sh in @($c.Shares)) { $list += [pscustomobject]@{ Share = [string]$sh.Share; Drive = $sh.Drive } }
            $remotes += [pscustomobject]@{ Name = [string]$c.HostName; IP = [string]$c.HostIP; User = [string]$c.UserName; Shares = @($list) }
        }
        $c | Add-Member -NotePropertyName Remotes -NotePropertyValue @($remotes) -Force
        $c | Add-Member -NotePropertyName LocalShares -NotePropertyValue @($local) -Force
        if (-not $c.ShareUser -and $c.UserName) { $c | Add-Member -NotePropertyName ShareUser -NotePropertyValue ([string]$c.UserName) -Force }
    }
    if ($null -eq $c.Remotes)     { $c | Add-Member -NotePropertyName Remotes     -NotePropertyValue @() -Force }
    if ($null -eq $c.LocalShares) { $c | Add-Member -NotePropertyName LocalShares -NotePropertyValue @() -Force }
    if (-not $c.ShareUser)        { $c | Add-Member -NotePropertyName ShareUser   -NotePropertyValue ($env:COMPUTERNAME + '\countshare') -Force }
    # "IsHost" now simply means: this PC shares at least one folder
    $c | Add-Member -NotePropertyName IsHost -NotePropertyValue ([bool](@($c.LocalShares).Count -gt 0)) -Force
    return $c
}

$cfg = Read-Config
$LogDir = Join-Path $env:LOCALAPPDATA 'ShareDoctor'
$LogFile = Join-Path $LogDir 'log.txt'

function Write-Log([string]$m) {
    try {
        if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null }
        if ((Test-Path $LogFile) -and ((Get-Item $LogFile).Length -gt 1MB)) { Move-Item $LogFile "$LogFile.old" -Force }
        Add-Content -LiteralPath $LogFile -Value ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m)
    } catch { }
}

# ---------------------------------------------------------------- elevated fixes (run with -Fix)
function ConvertTo-UInt([string]$ip) {
    $b = ([System.Net.IPAddress]::Parse($ip)).GetAddressBytes()
    return ([long]$b[0] * 16777216) + ([long]$b[1] * 65536) + ([long]$b[2] * 256) + [long]$b[3]
}
function ConvertFrom-UInt([long]$n) {
    return ('{0}.{1}.{2}.{3}' -f (($n -shr 24) -band 255), (($n -shr 16) -band 255), (($n -shr 8) -band 255), ($n -band 255))
}
# every IPv4 address range EXCEPT the allowed ones (used for the firewall block rule)
function Get-BlockRanges([string[]]$allowed) {
    $nums = @()
    foreach ($a in $allowed) {
        $tmp = $null
        if ($a -and [System.Net.IPAddress]::TryParse($a, [ref]$tmp) -and $tmp.AddressFamily -eq 'InterNetwork') { $nums += (ConvertTo-UInt $a) }
    }
    $nums = @($nums | Sort-Object -Unique)
    $ranges = @()
    $start = [long]0
    foreach ($n in $nums) {
        if ($n -gt $start) { $ranges += ((ConvertFrom-UInt $start) + '-' + (ConvertFrom-UInt ($n - 1))) }
        $start = $n + 1
    }
    if ($start -le 4294967295) { $ranges += ((ConvertFrom-UInt $start) + '-' + (ConvertFrom-UInt 4294967295)) }
    return $ranges
}

function Test-GuardWanted($c) { return [bool]($c.IsHost -or @($c.Printers).Count -gt 0) }

function Set-GuardTask([bool]$on) {
    $name = 'ShareDoctor Guard'
    if ($on) {
        $act = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $PSCommandPath + '" -Guard')
        $trg = New-ScheduledTaskTrigger -AtStartup
        $pri = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
        $set = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 5 -RestartInterval (New-TimeSpan -Minutes 1) -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
        Register-ScheduledTask -TaskName $name -Action $act -Trigger $trg -Principal $pri -Settings $set -Force | Out-Null
        $t = Get-ScheduledTask -TaskName $name
        Stop-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
        Start-ScheduledTask -TaskName $name
        Start-Sleep -Seconds 3
        if (-not (Test-Path -LiteralPath (Join-Path $env:ProgramData 'ShareDoctor\guard-alive.txt'))) { Write-Log 'Guard task was created but has not reported in yet' }
    } else {
        Stop-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName $name -Confirm:$false -ErrorAction SilentlyContinue
    }
}

function Save-Proposal([string]$file) {
    $new = Get-Content -LiteralPath $file -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    foreach ($rm in @($new.Remotes)) { if ([string]$rm.IP -notmatch '^\d{1,3}(\.\d{1,3}){3}$') { throw ('Invalid IP for ' + $rm.Name) } }
    foreach ($pc in @($new.AllowedPCs)) { if ([string]$pc.IP -notmatch '^\d{1,3}(\.\d{1,3}){3}$') { throw ('Invalid IP in the list of PCs: ' + $pc.IP) } }
    foreach ($old in @($cfg.LocalShares)) {
        if (-not (@($new.LocalShares) | Where-Object { $_.Share -eq $old.Share })) {
            Remove-SmbShare -Name $old.Share -Force -ErrorAction SilentlyContinue
            Write-Log ('Stopped sharing ' + $old.Share + ' (files not touched)')
        }
    }
    $pwText = [string]$new.SharePassword
    $acct = ([string]$new.ShareUser -split '\\')[-1]
    if ($pwText -and @($new.LocalShares).Count -gt 0) {
        $sec = ConvertTo-SecureString $pwText -AsPlainText -Force
        if (Get-LocalUser -Name $acct -ErrorAction SilentlyContinue) {
            Set-LocalUser -Name $acct -Password $sec
            Enable-LocalUser -Name $acct -ErrorAction SilentlyContinue
            Write-Log ('Updated the sharing login ' + $acct + ' on this PC')
        } else {
            New-LocalUser -Name $acct -Password $sec -PasswordNeverExpires -UserMayNotChangePassword -AccountNeverExpires -Description 'Created by Share Doctor for file sharing' | Out-Null
            Write-Log ('Created the sharing login ' + $acct + ' on this PC')
        }
    }
    $new.PSObject.Properties.Remove('SharePassword')
    $new | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $ConfigPath -Encoding UTF8
    Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue
    Write-Log 'Settings saved'
}

function Invoke-AdminFix([string]$name) {
    $arg = ''
    if ($name -match '^([^:]+):(.+)$') { $name = $Matches[1]; $arg = $Matches[2] }
    switch ($name) {
        'HostsPin' {
            if ($arg -match '^(.+)\|(\d{1,3}(\.\d{1,3}){3})$') { $rm = [pscustomobject]@{ Name = $Matches[1]; IP = $Matches[2] } }
            else { $rm = @($cfg.Remotes | Where-Object { [string]$_.Name -eq $arg })[0] }
            if (-not $rm) { throw ('Unknown PC ' + $arg) }
            $hosts = Join-Path $env:SystemRoot 'System32\drivers\etc\hosts'
            $lines = @(Get-Content -LiteralPath $hosts -ErrorAction SilentlyContinue)
            $pat = '^\s*[^#\s]+\s+.*\b' + [regex]::Escape([string]$rm.Name) + '\b'
            $keep = @($lines | Where-Object { $_ -notmatch $pat })
            $keep += ("{0}`t{1}" -f $rm.IP, $rm.Name)
            Set-Content -LiteralPath $hosts -Value $keep -Encoding ASCII
            & ipconfig.exe /flushdns | Out-Null
        }
        'ProfilePrivate' {
            $idx = @(Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -like ($cfg.ExpectedSubnet + '*') } |
                     Select-Object -ExpandProperty InterfaceIndex -Unique)
            foreach ($i in $idx) { Set-NetConnectionProfile -InterfaceIndex $i -NetworkCategory Private }
        }
        'NoSleep' {
            & powercfg.exe /change standby-timeout-ac 0
            & powercfg.exe /change hibernate-timeout-ac 0
            & powercfg.exe /change disk-timeout-ac 0
        }
        'ServerService' {
            Set-Service -Name LanmanServer -StartupType Automatic
            Start-Service -Name LanmanServer
        }
        'ApplyAccess' {
            # 1. shared folders on the shared-folder PC: create them, only the share login may open them
            if ($cfg.IsHost) {
                foreach ($sh in @($cfg.LocalShares)) {
                    if (-not $sh.Path) { continue }
                    try {
                        if (-not (Test-Path -LiteralPath $sh.Path)) { Write-Log ('Folder not found, not shared: ' + $sh.Path); continue }
                        $u = $cfg.ShareUser
                        if (-not (Get-SmbShare -Name $sh.Share -ErrorAction SilentlyContinue)) {
                            New-SmbShare -Name $sh.Share -Path $sh.Path -FullAccess $u -FolderEnumerationMode AccessBased | Out-Null
                            Write-Log ('Shared ' + $sh.Path + ' as ' + $sh.Share)
                        } else {
                            Grant-SmbShareAccess -Name $sh.Share -AccountName $u -AccessRight Full -Force | Out-Null
                            Revoke-SmbShareAccess -Name $sh.Share -AccountName 'Everyone' -Force -ErrorAction SilentlyContinue | Out-Null
                        }
                        & icacls.exe $sh.Path /grant ($u + ':(OI)(CI)M') | Out-Null
                    } catch { Write-Log ('Share ' + $sh.Share + ' failed: ' + $_.Exception.Message) }
                }
            }
            # 2. firewall: block file sharing from every PC that is not on the list
            try {
                $allowed = @('127.0.0.1')
                $allowed += @(Get-NetIPAddress -AddressFamily IPv4 | Select-Object -ExpandProperty IPAddress)
                if ($cfg.IsHost) { $allowed += @($cfg.AllowedPCs | ForEach-Object { $_.IP }) }
                $ranges = Get-BlockRanges $allowed
                Get-NetFirewallRule -Name 'ShareDoctor-BlockSMB' -ErrorAction SilentlyContinue | Remove-NetFirewallRule
                if ($cfg.EnforceAccess -ne $false) {
                    New-NetFirewallRule -Name 'ShareDoctor-BlockSMB' -DisplayName 'Share Doctor - block file sharing from PCs that are not on the list' `
                        -Direction Inbound -Action Block -Protocol TCP -LocalPort 445, 139 -RemoteAddress $ranges -Profile Any -Enabled True | Out-Null
                    Write-Log ('Blocking rule on. Allowed: ' + (($allowed | Select-Object -Unique) -join ', '))
                } else {
                    Write-Log 'Blocking rule removed (turned off in settings)'
                }
            } catch { Write-Log ('Firewall rule failed: ' + $_.Exception.Message) }
            # 2b. security log: record who opens the shared folders, wrong logins and blocked attempts
            if ($cfg.IsHost) {
                try {
                    & auditpol.exe /set /subcategory:"{0CCE9224-69AE-11D9-BED3-505054503030}" /success:enable /failure:enable | Out-Null   # File Share
                    & auditpol.exe /set /subcategory:"{0CCE9215-69AE-11D9-BED3-505054503030}" /success:enable /failure:enable | Out-Null   # Logon
                    & auditpol.exe /set /subcategory:"{0CCE9226-69AE-11D9-BED3-505054503030}" /failure:enable | Out-Null                    # Filtering Platform Connection (blocked)
                    & wevtutil.exe sl Security /ms:268435456 | Out-Null                                                                     # keep about 256 MB of history
                    Write-Log 'Security auditing for file sharing is on'
                } catch { Write-Log ('Auditing setup failed: ' + $_.Exception.Message) }
            }
            # 3. auto-repair task only on the shared-folder PC
            try { Set-GuardTask (Test-GuardWanted $cfg) } catch { Write-Log ('Guard task failed: ' + $_.Exception.Message) }
        }
        'AutoStart' {
            $startLnk = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\StartUp\Share Doctor.lnk'
            if ($arg -eq '1') {
                $wsh = New-Object -ComObject WScript.Shell
                $sc = $wsh.CreateShortcut($startLnk)
                $sc.TargetPath = Join-Path $env:SystemRoot 'System32\wscript.exe'
                $sc.Arguments = '"' + (Join-Path $PSScriptRoot 'Launch.vbs') + '"'
                $sc.WorkingDirectory = $PSScriptRoot
                $sc.IconLocation = (Join-Path $PSScriptRoot 'ShareDoctor.ico')
                $sc.Description = 'Share Doctor - checks the shared folders (by Ekin Ozgur)'
                $sc.Save()
                Write-Log 'Share Doctor will start with Windows'
            } else {
                Remove-Item -LiteralPath $startLnk -Force -ErrorAction SilentlyContinue
                Write-Log 'Share Doctor will NOT start with Windows'
            }
        }
        'Unshare' {
            if ($arg -notmatch '^([0-9a-f]{2})+$') { throw 'Bad share name' }
            $bytes = New-Object byte[] ($arg.Length / 2)
            for ($i = 0; $i -lt $bytes.Length; $i++) { $bytes[$i] = [Convert]::ToByte($arg.Substring(2 * $i, 2), 16) }
            $shName = [System.Text.Encoding]::UTF8.GetString($bytes)
            if ($shName.EndsWith('$')) { throw ('Windows system share ' + $shName + ' is left alone') }
            Remove-SmbShare -Name $shName -Force
            Write-Log ('Stopped sharing ' + $shName + ' (folder and files not touched)')
        }
        'Guard' {
            Set-GuardTask (Test-GuardWanted $cfg)
        }
        'RestartSharing' {
            Restart-Service -Name LanmanServer -Force
        }
        'Spooler' {
            Stop-Service -Name Spooler -Force -ErrorAction SilentlyContinue
            Remove-Item -Path (Join-Path $env:SystemRoot 'System32\spool\PRINTERS\*') -Force -ErrorAction SilentlyContinue
            Set-Service -Name Spooler -StartupType Automatic
            Start-Service -Name Spooler
        }
        'Firewall' {
            Enable-NetFirewallRule -DisplayGroup 'File and Printer Sharing'
        }
    }
}

if ($Update) {
    try {
        Start-Sleep -Seconds 2
        Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
            Where-Object { $_.CommandLine -like '*ShareDoctor.ps1*' -and $_.ProcessId -ne $PID } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
        Start-Sleep -Seconds 1
        $dest = $PSScriptRoot
        foreach ($f in @('ShareDoctor.ps1', 'Launch.vbs', 'ShareDoctor.ico')) {
            $src = Join-Path $Update $f
            if (Test-Path -LiteralPath $src) { Copy-Item -LiteralPath $src -Destination (Join-Path $dest $f) -Force }
        }
        Remove-Item -LiteralPath $Update -Recurse -Force -ErrorAction SilentlyContinue
        if (Get-ScheduledTask -TaskName 'ShareDoctor Guard' -ErrorAction SilentlyContinue) { Stop-ScheduledTask -TaskName 'ShareDoctor Guard' -ErrorAction SilentlyContinue; Start-ScheduledTask -TaskName 'ShareDoctor Guard' }
        Write-Log 'Updated Share Doctor files'
        $lnk = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\StartUp\Share Doctor.lnk'
        if (Test-Path $lnk) { Start-Process explorer.exe -ArgumentList ('"' + $lnk + '"') }
    } catch { Write-Log ('Update FAILED: ' + $_.Exception.Message) }
    exit
}

if ($Fix) {
    if ($Proposal -and (Test-Path -LiteralPath $Proposal)) {
        try { Save-Proposal $Proposal; $cfg = Read-Config }
        catch { Write-Log ('Settings NOT saved: ' + $_.Exception.Message); exit }
    }
    $fixOut = @()
    foreach ($f in ($Fix -split ',')) {
        $f = $f.Trim()
        if (-not $f) { continue }
        try { Invoke-AdminFix $f; Write-Log "Admin fix '$f' done"; $fixOut += ('OK ' + $f) }
        catch { Write-Log "Admin fix '$f' FAILED: $($_.Exception.Message)"; $fixOut += ('FAILED ' + $f + ': ' + $_.Exception.Message) }
    }
    try {
        $rd = Join-Path $env:ProgramData 'ShareDoctor'
        if (-not (Test-Path $rd)) { New-Item -ItemType Directory -Path $rd -Force | Out-Null }
        Set-Content -LiteralPath (Join-Path $rd 'fix-result.txt') -Value $fixOut -Encoding UTF8
    } catch { }
    exit
}

$ErrorActionPreference = 'Continue'

function Test-TcpPort($h, $port, $ms) {
    $c = New-Object System.Net.Sockets.TcpClient
    try {
        $a = $c.BeginConnect($h, $port, $null, $null)
        if (-not $a.AsyncWaitHandle.WaitOne($ms)) { return $false }
        try { $c.EndConnect($a) } catch { return $false }
        return $c.Connected
    } catch { return $false }
    finally { $c.Close() }
}

function Write-GuardLog([string]$m) {
    try {
        $d = Join-Path $env:ProgramData 'ShareDoctor'
        if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
        $f = Join-Path $d 'guard.log'
        if ((Test-Path $f) -and ((Get-Item $f).Length -gt 1MB)) { Move-Item $f "$f.old" -Force }
        Add-Content -LiteralPath $f -Value ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m)
    } catch { }
}

function Set-GuardStatus([string]$m) {
    try { Set-Content -LiteralPath (Join-Path $env:ProgramData 'ShareDoctor\guard-status.txt') -Value ((Get-Date -Format 'yyyy-MM-dd h:mm tt') + '|' + $m) -Encoding ASCII } catch { }
}

# ---- Guard mode: on the shared-folder PC, repairs file sharing by itself (instead of restarting the PC)
if ($Guard) {
    $gm = New-Object System.Threading.Mutex($false, 'Global\ShareDoctorGuard')
    if (-not $gm.WaitOne(0)) { exit }
    Write-GuardLog 'Guard started'
    $bad = 0; $step = 0; $lastAct = [datetime]::MinValue; $acts = @(); $spBad = 0
    while ($true) {
        try {
            $hb = Join-Path $env:ProgramData 'ShareDoctor\guard-alive.txt'
            try { $hd = Split-Path -Parent $hb; if (-not (Test-Path $hd)) { New-Item -ItemType Directory -Path $hd -Force | Out-Null }; Set-Content -LiteralPath $hb -Value (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') -Encoding ASCII } catch { }
            $c = Read-Config
            if (@($c.Printers).Count -gt 0) {
                $spSvc = Get-Service -Name Spooler -ErrorAction SilentlyContinue
                if ($spSvc -and $spSvc.Status -ne 'Running') {
                    $spBad++
                    if ($spBad -ge 2) {
                        try { Start-Service -Name Spooler -ErrorAction Stop; Write-GuardLog 'Print Spooler was stopped - started it again'; Set-GuardStatus 'Restarted the print service (Print Spooler)' } catch { Write-GuardLog ('Could not start the Print Spooler: ' + $_.Exception.Message) }
                        $spBad = 0
                    }
                } else { $spBad = 0 }
            }
            if (-not $c.IsHost) { $bad = 0; $step = 0; Start-Sleep -Seconds 60; continue }
            $has = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -like ($c.ExpectedSubnet + '*') })
            if ($has.Count -eq 0) {
                $bad = 0        # no address on the casino network (cable out / IP changed): not a sharing fault
            } else {
                $selfIp = [string]$has[0].IPAddress
                $svc = Get-Service -Name LanmanServer -ErrorAction SilentlyContinue
                $portOk = Test-TcpPort $selfIp 445 3000
                $viewBad = $false
                if ($portOk) {
                    $o = (& net.exe view ("\\" + $selfIp) 2>&1) -join ' '
                    if ($o -match 'System error (53|64|67|121|1222|1231)') { $viewBad = $true }
                }
                if ($svc -and $svc.Status -eq 'Running' -and $portOk -and -not $viewBad) {
                    if ($bad -ge 2) { Write-GuardLog 'File sharing is healthy again' }
                    $bad = 0; $step = 0
                } else {
                    $bad++
                    Write-GuardLog ("Unhealthy check {0} (service={1} port445={2} netview-error={3})" -f $bad, $svc.Status, $portOk, $viewBad)
                }
                if ($bad -ge 2 -and (((Get-Date) - $lastAct).TotalMinutes -ge 4)) {
                    $acts = @($acts | Where-Object { ((Get-Date) - $_).TotalMinutes -lt 60 })
                    if ($acts.Count -ge 4) {
                        Write-GuardLog 'Already tried 4 times this hour - this one needs a person (restart the PC)'
                        Set-GuardStatus 'Could not repair automatically - restart the PC'
                    } else {
                        $lastAct = Get-Date; $acts += $lastAct; $step++
                        if ($step -le 2) {
                            Write-GuardLog 'Repair: restarting the Server service'
                            try { Restart-Service -Name LanmanServer -Force; Set-GuardStatus 'Restarted the file-sharing service (no PC restart needed)' }
                            catch { Write-GuardLog ('Restart failed: ' + $_.Exception.Message) }
                        } else {
                            Write-GuardLog 'Repair: resetting the network adapter'
                            foreach ($i in @($has | Select-Object -ExpandProperty InterfaceIndex -Unique)) {
                                try { Get-NetAdapter -InterfaceIndex $i | Restart-NetAdapter } catch { Write-GuardLog ('Adapter reset failed: ' + $_.Exception.Message) }
                            }
                            Set-GuardStatus 'Reset the network adapter (no PC restart needed)'
                        }
                        $bad = 0
                    }
                }
            }
        } catch { Write-GuardLog ('Guard error: ' + $_.Exception.Message) }
        Start-Sleep -Seconds 30
    }
}


# ---- Activity mode: elevated window that shows who connected to what (reads the Windows Security log)
function ConvertTo-ActivityRow([int]$id, $d, [datetime]$time, $cfg) {
    $ip = ''; $user = ''; $what = ''; $kind = ''; $result = ''
    if ($id -eq 5140) {
        $what = ([string]$d['ShareName']) -replace '^\\\\\*\\', ''
        if ($what -match '^IPC\$$') { return $null }
        $ip = [string]$d['IpAddress']; $user = ([string]$d['SubjectDomainName'] + '\' + [string]$d['SubjectUserName'])
        $kind = 'Opened a shared folder'; $result = 'Allowed'
    } elseif ($id -eq 4625) {
        $ip = [string]$d['IpAddress']; $user = ([string]$d['TargetDomainName'] + '\' + [string]$d['TargetUserName'])
        $what = 'Login refused'; $kind = 'Wrong login'; $result = 'Refused'
    } elseif ($id -eq 5157) {
        if ([string]$d['Direction'] -ne '%%14592') { return $null }
        if (@('445', '139') -notcontains [string]$d['DestPort']) { return $null }
        $ip = [string]$d['SourceAddress']; $what = ('File sharing port ' + [string]$d['DestPort'])
        $kind = 'Blocked'; $result = 'Blocked'
    } else { return $null }
    if ($ip -match '^::ffff:(.+)$') { $ip = $Matches[1] }
    $name = ''
    foreach ($pc in @($cfg.AllowedPCs)) { if ([string]$pc.IP -eq $ip) { $name = [string]$pc.Name } }
    if (-not $name) {
        if ($ip -eq '127.0.0.1' -or $ip -eq '::1') { $name = 'This PC' }
        elseif (-not $ip -or $ip -eq '-') { $name = '(unknown)'; $ip = '' }
        else { $name = 'Unknown PC' }
    }
    return [pscustomobject]@{ Time = $time.ToString('yyyy-MM-dd HH:mm:ss'); Event = $kind; PC = $name; IP = $ip; User = $user; Detail = $what; Result = $result }
}

function Get-Activity([datetime]$since, $cfg) {
    $rows = @()
    foreach ($id in @(5140, 4625, 5157)) {
        $evs = @()
        try { $evs = @(Get-WinEvent -FilterHashtable @{ LogName = 'Security'; Id = $id; StartTime = $since } -MaxEvents 5000 -ErrorAction Stop) } catch { $evs = @() }
        foreach ($e in $evs) {
            $x = [xml]$e.ToXml()
            $d = @{}
            foreach ($n in $x.Event.EventData.Data) { $d[[string]$n.Name] = [string]$n.'#text' }
            $r = ConvertTo-ActivityRow $id $d $e.TimeCreated $cfg
            if ($r) { $rows += $r }
        }
    }
    return @($rows | Sort-Object Time -Descending)
}

if ($Activity) {
    Add-Type -AssemblyName System.Windows.Forms
try {
    Add-Type -Namespace SD -Name Shell -MemberDefinition '[System.Runtime.InteropServices.DllImport("shell32.dll")] public static extern void SetCurrentProcessExplicitAppUserModelID([System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string id);' -ErrorAction Stop
    [SD.Shell]::SetCurrentProcessExplicitAppUserModelID('CasinoIT.ShareDoctor')
} catch { }
    Add-Type -AssemblyName System.Drawing
    Add-Type -AssemblyName System.Data
    [System.Windows.Forms.Application]::EnableVisualStyles()
    $script:dt = New-Object System.Data.DataTable
    foreach ($c in @('Time', 'Event', 'PC', 'IP', 'User', 'Detail', 'Result')) { [void]$script:dt.Columns.Add($c) }

    $f = New-Object System.Windows.Forms.Form
    try { $f.Icon = New-Object System.Drawing.Icon (Join-Path $PSScriptRoot 'ShareDoctor.ico') } catch { }
    $f.Text = 'Share Doctor - Who connected'
    $f.Size = New-Object System.Drawing.Size(1000, 640)
    $f.StartPosition = 'CenterScreen'
    $f.BackColor = [System.Drawing.Color]::FromArgb(244, 246, 248)
    $f.Font = New-Object System.Drawing.Font('Segoe UI', 10)

    $sum = New-Object System.Windows.Forms.Label
    $sum.Location = New-Object System.Drawing.Point(16, 12); $sum.Size = New-Object System.Drawing.Size(950, 28)
    $sum.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 12)
    $f.Controls.Add($sum)

    $cbPeriod = New-Object System.Windows.Forms.ComboBox
    $cbPeriod.DropDownStyle = 'DropDownList'; $cbPeriod.Location = New-Object System.Drawing.Point(16, 48); $cbPeriod.Size = New-Object System.Drawing.Size(150, 28)
    [void]$cbPeriod.Items.AddRange(@('Last hour', 'Last 24 hours', 'Last 7 days', 'Last 30 days')); $cbPeriod.SelectedIndex = 1
    $cbType = New-Object System.Windows.Forms.ComboBox
    $cbType.DropDownStyle = 'DropDownList'; $cbType.Location = New-Object System.Drawing.Point(176, 48); $cbType.Size = New-Object System.Drawing.Size(210, 28)
    [void]$cbType.Items.AddRange(@('Everything', 'Opened a shared folder', 'Wrong login', 'Blocked')); $cbType.SelectedIndex = 0
    $tbFind = New-Object System.Windows.Forms.TextBox
    $tbFind.Location = New-Object System.Drawing.Point(396, 49); $tbFind.Size = New-Object System.Drawing.Size(220, 26)
    $btnGo = New-Object System.Windows.Forms.Button
    $btnGo.Text = 'Refresh'; $btnGo.Location = New-Object System.Drawing.Point(630, 46); $btnGo.Size = New-Object System.Drawing.Size(100, 32)
    $btnExp = New-Object System.Windows.Forms.Button
    $btnExp.Text = 'Save as CSV'; $btnExp.Location = New-Object System.Drawing.Point(740, 46); $btnExp.Size = New-Object System.Drawing.Size(120, 32)
    $f.Controls.AddRange(@($cbPeriod, $cbType, $tbFind, $btnGo, $btnExp))
    $hint = New-Object System.Windows.Forms.Label
    $hint.Text = 'Type a PC name, IP or folder in the box to filter.'
    $hint.ForeColor = [System.Drawing.Color]::Gray; $hint.Location = New-Object System.Drawing.Point(396, 78); $hint.Size = New-Object System.Drawing.Size(400, 20)
    $hint.Font = New-Object System.Drawing.Font('Segoe UI', 8.5)
    $f.Controls.Add($hint)

    $grid = New-Object System.Windows.Forms.DataGridView
    $grid.Location = New-Object System.Drawing.Point(16, 104); $grid.Size = New-Object System.Drawing.Size(950, 480)
    $grid.Anchor = 'Top,Left,Right,Bottom'; $grid.ReadOnly = $true; $grid.AllowUserToAddRows = $false; $grid.RowHeadersVisible = $false
    $grid.BackgroundColor = [System.Drawing.Color]::White; $grid.BorderStyle = 'FixedSingle'; $grid.AutoSizeColumnsMode = 'Fill'; $grid.SelectionMode = 'FullRowSelect'
    $grid.DataSource = $script:dt
    $f.Controls.Add($grid)
    $grid.Add_CellFormatting({
        param($sender, $e)
        if ($e.RowIndex -ge 0) {
            $res = [string]$grid.Rows[$e.RowIndex].Cells['Result'].Value
            $pc = [string]$grid.Rows[$e.RowIndex].Cells['PC'].Value
            if ($res -eq 'Blocked') { $e.CellStyle.ForeColor = [System.Drawing.Color]::Firebrick }
            elseif ($res -eq 'Refused') { $e.CellStyle.ForeColor = [System.Drawing.Color]::DarkOrange }
            elseif ($pc -eq 'Unknown PC') { $e.CellStyle.ForeColor = [System.Drawing.Color]::Firebrick }
        }
    })

    $load = {
        $f.Cursor = 'WaitCursor'
        $span = @(1, 24, 168, 720)[$cbPeriod.SelectedIndex]
        $script:all = @(Get-Activity (Get-Date).AddHours(-$span) $cfg)
        $script:dt.Rows.Clear()
        foreach ($r in $script:all) { [void]$script:dt.Rows.Add($r.Time, $r.Event, $r.PC, $r.IP, $r.User, $r.Detail, $r.Result) }
        $opened = @($script:all | Where-Object { $_.Event -eq 'Opened a shared folder' }).Count
        $blocked = @($script:all | Where-Object { $_.Event -eq 'Blocked' }).Count
        $wrong = @($script:all | Where-Object { $_.Event -eq 'Wrong login' }).Count
        $sum.Text = "$opened folder opens  -  $blocked blocked attempts  -  $wrong wrong logins"
        $f.Cursor = 'Default'
    }
    $filter = {
        $parts = @()
        if ($cbType.SelectedIndex -gt 0) { $parts += ("Event = '" + $cbType.SelectedItem.ToString().Replace("'", "''") + "'") }
        $q = $tbFind.Text.Trim().Replace("'", "''").Replace('[', '[[]').Replace('%', '[%]').Replace('*', '[*]')
        if ($q) { $parts += ("(PC LIKE '%$q%' OR IP LIKE '%$q%' OR User LIKE '%$q%' OR Detail LIKE '%$q%')") }
        try { $script:dt.DefaultView.RowFilter = ($parts -join ' AND ') } catch { }
    }
    $btnGo.Add_Click({ & $load; & $filter })
    $cbPeriod.Add_SelectedIndexChanged({ & $load; & $filter })
    $cbType.Add_SelectedIndexChanged({ & $filter })
    $tbFind.Add_TextChanged({ & $filter })
    $btnExp.Add_Click({
        $sd = New-Object System.Windows.Forms.SaveFileDialog
        $sd.Filter = 'CSV file (*.csv)|*.csv'; $sd.FileName = 'who-connected-' + (Get-Date -Format 'yyyy-MM-dd') + '.csv'
        if ($sd.ShowDialog() -eq 'OK') { $script:all | Export-Csv -LiteralPath $sd.FileName -NoTypeInformation -Encoding UTF8 }
    })
    $f.Add_Shown({ & $load })
    [void]$f.ShowDialog()
    exit
}

# ---------------------------------------------------------------- the checks (run in a background runspace)
$CheckScript = {
    param($cfg)
    $ErrorActionPreference = 'SilentlyContinue'
    $out = New-Object System.Collections.ArrayList

    function Add-Result($id, $title, $status, $detail, $fix) {
        [void]$out.Add([pscustomobject]@{ Id = $id; Title = $title; Status = $status; Detail = $detail; Fix = $fix })
    }
    function Test-Ping($h) {
        $p = New-Object System.Net.NetworkInformation.Ping
        for ($i = 0; $i -lt 2; $i++) {
            try { $r = $p.Send($h, 1500); if ($r.Status -eq 'Success') { return $true } } catch { }
        }
        return $false
    }
    function Test-Tcp($h, $port, $ms) {
        $c = New-Object System.Net.Sockets.TcpClient
        try {
            $a = $c.BeginConnect($h, $port, $null, $null)
            if (-not $a.AsyncWaitHandle.WaitOne($ms)) { return $false }
            try { $c.EndConnect($a) } catch { return $false }
            return $c.Connected
        } catch { return $false }
        finally { $c.Close() }
    }

    # 1. this PC is on the casino network
    $mine = @(Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -like ($cfg.ExpectedSubnet + '*') })
    if ($mine.Count -gt 0) {
        Add-Result 'lan' 'This PC is on the casino network' 'OK' ('Address ' + $mine[0].IPAddress) $null
    } else {
        Add-Result 'lan' 'This PC is on the casino network' 'FAIL' ('No ' + $cfg.ExpectedSubnet + 'x address. Check the network cable / WiFi.') $null
    }

    # 2. router
    if ($cfg.Gateway) {
        if (Test-Ping $cfg.Gateway) { Add-Result 'gw' 'Router reachable' 'OK' ('Replies from ' + $cfg.Gateway) $null }
        else { Add-Result 'gw' 'Router reachable' 'FAIL' ('No reply from ' + $cfg.Gateway + '. Network cable, switch or router problem.') $null }
    }

    # 3. every PC this PC opens folders from
    foreach ($rm in @($cfg.Remotes)) {
        $rn = [string]$rm.Name; $rip = [string]$rm.IP
        $pingOk = Test-Ping $rip
        $smbOk  = Test-Tcp $rip 445 2500

        if ($pingOk) { Add-Result ('ping:' + $rn) ($rn + ' answers') 'OK' ($rn + ' (' + $rip + ') replies to ping') $null }
        elseif ($smbOk) { Add-Result ('ping:' + $rn) ($rn + ' answers') 'SKIP' 'No ping reply, but file sharing is open (ping is probably blocked - normal)' $null }
        else { Add-Result ('ping:' + $rn) ($rn + ' answers') 'FAIL' ($rn + ' (' + $rip + ') does not reply. It may be off, asleep, unplugged, or its IP changed.') $null }

        $resolved = @()
        try {
            $resolved = @([System.Net.Dns]::GetHostAddresses($rn) |
                          Where-Object { $_.AddressFamily -eq 'InterNetwork' } | ForEach-Object { $_.ToString() })
        } catch { }
        $pinFix = 'HostsPin:' + $rn + '|' + $rip
        if ($resolved.Count -eq 0) {
            Add-Result ('name:' + $rn) ($rn + ' name found') 'WARN' ('The name "' + $rn + '" cannot be found on the network. Drives use the IP so this is not urgent. "Pin the name" fixes it.') $pinFix
        } elseif ($resolved -contains $rip) {
            Add-Result ('name:' + $rn) ($rn + ' name found') 'OK' ($rn + ' = ' + $rip) $null
        } else {
            Add-Result ('name:' + $rn) ($rn + ' name found') 'WARN' ('The name points to ' + ($resolved -join ', ') + ' but settings say ' + $rip + '.') $pinFix
        }

        if ($smbOk) {
            Add-Result ('smb:' + $rn) ($rn + ' file sharing open') 'OK' 'Port 445 open' $null
        } else {
            $moved = $null
            foreach ($ip in $resolved) { if ($ip -ne $rip -and (Test-Tcp $ip 445 1500)) { $moved = $ip } }
            if ($moved) {
                Add-Result ('smb:' + $rn) ($rn + ' file sharing open') 'FAIL' ($rn + ' now answers on ' + $moved + ', not ' + $rip + '. Its IP changed: click Settings and change its IP (and give it a fixed IP in UniFi).') $null
            } elseif ($pingOk) {
                Add-Result ('smb:' + $rn) ($rn + ' file sharing open') 'FAIL' ('The PC is on but file sharing is closed on it. Open Share Doctor on ' + $rn + ': it shows why (Server service, firewall, network set to Public). If blocking is on there, THIS PC must be in its "Who may connect" list.') $null
            } else {
                Add-Result ('smb:' + $rn) ($rn + ' file sharing open') 'FAIL' 'Cannot connect.' $null
            }
        }

        # saved login for that PC
        $cl = (& cmdkey.exe /list) -join "`n"
        $hasName = $cl -match ('(?i)target=.*' + [regex]::Escape($rn))
        $hasIp   = $cl -match ('(?i)target=.*' + [regex]::Escape($rip))
        $credFix = 'Creds:' + $rn
        if ($hasIp) { Add-Result ('cred:' + $rn) ('Login for ' + $rn) 'OK' ('Login saved for ' + $rip) $null }
        elseif ($hasName) { Add-Result ('cred:' + $rn) ('Login for ' + $rn) 'WARN' 'Login is saved under the name but not the IP. Re-enter it once.' $credFix }
        else { Add-Result ('cred:' + $rn) ('Login for ' + $rn) 'WARN' ('No saved login for ' + $rn + '.') $credFix }

        # each folder from that PC, and its drive letter
        foreach ($s in @($rm.Shares)) {
            $unc = '\\' + $rip + '\' + $s.Share
            $title = [string]$s.Share + ' on ' + $rn
            $remapFix = 'Remap:' + $rn
            if (-not $smbOk) {
                Add-Result ('share:' + $rn + ':' + $s.Share) $title 'SKIP' ('Waiting for ' + $rn) $null
                if ($s.Drive) { Add-Result ('drive:' + $rn + ':' + $s.Share) ('Drive ' + $s.Drive + ' (' + $title + ')') 'SKIP' ('Waiting for ' + $rn) $null }
                continue
            }
            $err = $null
            try { $null = Get-ChildItem -LiteralPath $unc -Force -ErrorAction Stop | Select-Object -First 1 }
            catch { $err = $_.Exception.Message }
            if (-not $err) {
                Add-Result ('share:' + $rn + ':' + $s.Share) $title 'OK' ('Can open ' + $unc) $null
            } elseif ($err -match '(?i)denied|password|logon|credential|authenticat|not allowed') {
                Add-Result ('share:' + $rn + ':' + $s.Share) $title 'FAIL' ('The PC refused the login (wrong or expired password). ' + $err) $credFix
            } elseif ($err -match '(?i)network path|not find|does not exist|network name') {
                Add-Result ('share:' + $rn + ':' + $s.Share) $title 'FAIL' ('The share "' + $s.Share + '" was not found on ' + $rn + '. Was it renamed or unshared? ' + $err) $null
            } else {
                Add-Result ('share:' + $rn + ':' + $s.Share) $title 'FAIL' $err $null
            }

            if ($s.Drive) {
                $d = $s.Drive
                $m = Get-CimInstance Win32_NetworkConnection | Where-Object { $_.LocalName -eq $d } | Select-Object -First 1
                $dtitle = 'Drive ' + $d + ' (' + $title + ')'
                if (-not $m) {
                    Add-Result ('drive:' + $rn + ':' + $s.Share) $dtitle 'WARN' ('Drive ' + $d + ' is not mapped.') $remapFix
                } else {
                    $remote = [string]$m.RemoteName
                    $okPath = ($remote -ieq $unc) -or ($remote -ieq ('\\' + $rn + '\' + $s.Share))
                    if (-not $okPath) {
                        Add-Result ('drive:' + $rn + ':' + $s.Share) $dtitle 'WARN' ('Drive ' + $d + ' points to ' + $remote + ' instead of ' + $unc + '.') $remapFix
                    } elseif (-not (Test-Path -LiteralPath ($d + '\'))) {
                        Add-Result ('drive:' + $rn + ':' + $s.Share) $dtitle 'WARN' ('Drive ' + $d + ' shows as disconnected.') $remapFix
                    } else {
                        Add-Result ('drive:' + $rn + ':' + $s.Share) $dtitle 'OK' ($d + ' = ' + $remote) $null
                    }
                }
            }
        }
    }

    # who may reach this PC
    if ($cfg.EnforceAccess -ne $false) {
        try {
            $ar = Get-NetFirewallRule -Name 'ShareDoctor-BlockSMB' -ErrorAction Stop
            if ([string]$ar.Enabled -eq 'True') {
                if ($cfg.IsHost) { Add-Result 'access' 'Only approved PCs can open the shared folders' 'OK' ([string]@($cfg.AllowedPCs).Count + ' PC(s) on the list. Every other PC is blocked.') $null }
                else { Add-Result 'access' 'Other PCs cannot reach this PC' 'OK' 'File sharing from other PCs is blocked' $null }
            } else {
                Add-Result 'access' 'Other PCs cannot reach this PC' 'WARN' 'The blocking rule is switched off.' 'ApplyAccess'
            }
        } catch {
            if ($_.Exception.Message -match 'No MSFT|not found|No matching') { Add-Result 'access' 'Other PCs cannot reach this PC' 'WARN' 'Not set up yet. "Block PCs that are not allowed" turns it on.' 'ApplyAccess' }
            else { Add-Result 'access' 'Other PCs cannot reach this PC' 'SKIP' 'Could not read the firewall rules' $null }
        }
    }

    # printers (problems here only turn the circle yellow - a printer switched off at night is normal)
    if (@($cfg.Printers).Count -gt 0) {
        $sp = Get-Service -Name Spooler
        if ($sp -and $sp.Status -eq 'Running') {
            $stuck = 0
            try {
                foreach ($pn in @(Get-Printer -ErrorAction Stop | Select-Object -ExpandProperty Name)) {
                    foreach ($j in @(Get-PrintJob -PrinterName $pn -ErrorAction SilentlyContinue)) {
                        $old = $j.SubmittedTime -and (((Get-Date) - $j.SubmittedTime).TotalMinutes -gt 15)
                        if ($old -or ([string]$j.JobStatus -match 'Error|Offline|Blocked|Paper|Deleting')) { $stuck++ }
                    }
                }
            } catch { }
            if ($stuck -gt 0) { Add-Result 'spooler' 'Printing on this PC' 'WARN' ([string]$stuck + ' print job(s) look stuck. "Restart printing" clears them.') 'Spooler' }
            else { Add-Result 'spooler' 'Printing on this PC' 'OK' 'Print service running, no stuck jobs' $null }
        } else {
            Add-Result 'spooler' 'Printing on this PC' 'WARN' 'The Print Spooler service is stopped, so nothing can print.' 'Spooler'
        }
        foreach ($pr in @($cfg.Printers)) {
            $pname = [string]$pr.Name
            if (-not $pname) { continue }
            $pip = [string]$pr.IP
            $ptitle = 'Printer ' + $pname
            $problems = @(); $goods = @()
            $q = $null
            try { $q = Get-Printer -Name $pname -ErrorAction Stop } catch { }
            if ($q) {
                $st = [string]$q.PrinterStatus
                if ($st -and $st -notmatch '^(Normal|Idle|Printing|Processing|Busy|WarmingUp|Waiting|PowerSave|Initializing)$') {
                    $txt = $st -creplace '([a-z])([A-Z])', '$1 $2'
                    $problems += ('Windows reports: ' + $txt)
                } else { $goods += 'Windows says ready' }
                try {
                    $wq = "Name='" + ($pname -replace '\\', '\\' -replace "'", "\'") + "'"
                    $cim = Get-CimInstance Win32_Printer -Filter $wq -ErrorAction Stop
                    if ($cim -and $cim.WorkOffline) { $problems += 'It is set to "Use Printer Offline" in Windows. Open Printers, right-click it, and untick that.' }
                } catch { }
                $stuckN = 0
                try { foreach ($j in @(Get-PrintJob -PrinterName $pname -ErrorAction SilentlyContinue)) { if (([string]$j.JobStatus -match 'Error|Offline|Blocked|Paper') -or ($j.SubmittedTime -and (((Get-Date) - $j.SubmittedTime).TotalMinutes -gt 15))) { $stuckN++ } } } catch { }
                if ($stuckN -gt 0) { $problems += ([string]$stuckN + ' stuck job(s) in its queue. "Restart printing" clears them.') }
            } elseif ($pname.StartsWith('\\')) {
                $hostName = ($pname -split '\\')[2]
                $hostIp = ''
                foreach ($rm in @($cfg.Remotes)) { if ([string]$rm.Name -ieq $hostName) { $hostIp = [string]$rm.IP } }
                if ($hostIp -and -not (Test-Tcp $hostIp 445 2000)) { $problems += ($hostName + ' (which shares this printer) does not answer.') }
                else { $goods += ('Shared by ' + $hostName + '; not connected on this PC yet (Settings > Printers > Connect)') }
            } elseif (-not $pip) {
                $problems += 'This printer is not installed on this PC any more.'
            }
            if ($pip) {
                $port = 9100
                if ($pr.Port) { $port = [int]$pr.Port }
                $pingP = Test-Ping $pip
                $tcpP  = Test-Tcp $pip $port 2000
                if ($tcpP) { $goods += ($pip + ' answers') }
                elseif ($pingP) { $problems += ($pip + ' is on the network but not accepting print jobs. It may be asleep, busy, or showing an error on its screen.') }
                else { $problems += ($pip + ' does not answer. Is it switched on and the cable plugged in? If its IP changed, update it in Settings.') }
            }
            if ($problems.Count -gt 0) { Add-Result ('printer:' + $pname) $ptitle 'WARN' ($problems -join ' ') $null }
            else { Add-Result ('printer:' + $pname) $ptitle 'OK' ($goods -join '; ') $null }
        }
    }

    # checks that only matter when this PC shares folders
    if ($cfg.IsHost) {
        if ($mine.Count -gt 0) {
            if (Test-Tcp $mine[0].IPAddress 445 2500) { Add-Result 'selfsmb' 'File sharing is open on this PC' 'OK' ('Port 445 answers on ' + $mine[0].IPAddress) $null }
            else { Add-Result 'selfsmb' 'File sharing is open on this PC' 'FAIL' 'This PC does not answer on the file-sharing port, so other PCs cannot open its folders.' 'RestartSharing' }
        }

        $bad = $false
        foreach ($i in @($mine | Select-Object -ExpandProperty InterfaceIndex -Unique)) {
            $p = Get-NetConnectionProfile -InterfaceIndex $i
            if ($p -and ([string]$p.NetworkCategory -eq 'Public')) { $bad = $true }
        }
        if ($bad) { Add-Result 'profile' 'Network type is Private' 'FAIL' 'The network is set to Public, which blocks file sharing (Windows updates sometimes do this).' 'ProfilePrivate' }
        else { Add-Result 'profile' 'Network type is Private' 'OK' 'Not Public' $null }

        $svc = Get-Service -Name LanmanServer
        if ($svc -and $svc.Status -eq 'Running') { Add-Result 'server' 'Windows "Server" service' 'OK' 'Running' $null }
        else { Add-Result 'server' 'Windows "Server" service' 'FAIL' 'The Server service is stopped, so nothing can be shared.' 'ServerService' }

        try {
            $fw = @(Get-NetFirewallRule -DisplayGroup 'File and Printer Sharing' -ErrorAction Stop |
                    Where-Object { [string]$_.Enabled -eq 'True' -and [string]$_.Direction -eq 'Inbound' })
            if ($fw.Count -gt 0) { Add-Result 'fw' 'Firewall allows file sharing' 'OK' ($fw.Count.ToString() + ' rules on') $null }
            else { Add-Result 'fw' 'Firewall allows file sharing' 'WARN' 'The "File and Printer Sharing" firewall rules are off.' 'Firewall' }
        } catch { Add-Result 'fw' 'Firewall allows file sharing' 'SKIP' 'Could not read firewall rules (needs administrator)' $null }

        foreach ($s in @($cfg.LocalShares)) {
            try {
                $sh = Get-SmbShare -Name $s.Share -ErrorAction Stop
                Add-Result ('hshare:' + $s.Share) ('Share "' + $s.Share + '" exists') 'OK' ([string]$sh.Path) $null
            } catch { Add-Result ('hshare:' + $s.Share) ('Share "' + $s.Share + '" exists') 'SKIP' 'Could not read shares (needs administrator) or share is missing' $null }
        }

        # a standard-rights check cannot always SEE the SYSTEM task, so the repair task writes a heartbeat file we can read
        $gt = Get-ScheduledTask -TaskName 'ShareDoctor Guard' -ErrorAction SilentlyContinue
        $hbFile = Join-Path $env:ProgramData 'ShareDoctor\guard-alive.txt'
        $alive = $false
        if (Test-Path -LiteralPath $hbFile) { $alive = ((Get-Date) - (Get-Item -LiteralPath $hbFile).LastWriteTime).TotalSeconds -lt 180 }
        $gsf = Join-Path $env:ProgramData 'ShareDoctor\guard-status.txt'
        $last = 'No repair needed so far.'
        if (Test-Path $gsf) { $parts = (Get-Content -LiteralPath $gsf -ErrorAction SilentlyContinue | Select-Object -First 1) -split '\|', 2; if ($parts.Count -eq 2) { $last = 'Last auto-repair: ' + $parts[1] + ' (' + $parts[0] + ')' } }
        if ($alive) { Add-Result 'guard' 'Automatic repair of file sharing' 'OK' ('Watching. ' + $last) $null }
        elseif (-not $gt) { Add-Result 'guard' 'Automatic repair of file sharing' 'WARN' 'Automatic repair is not turned on yet (or not running). Fix all problems turns it on.' 'Guard' }
        else { Add-Result 'guard' 'Automatic repair of file sharing' 'WARN' ('The auto-repair task is not running (' + [string]$gt.State + '). Fix all problems starts it. ' + $last) 'Guard' }

        $q = (& powercfg.exe /query SCHEME_CURRENT SUB_SLEEP STANDBYIDLE) -join "`n"
        if ($q -match 'Current AC Power Setting Index:\s*0x([0-9a-fA-F]+)') {
            $sec = [Convert]::ToInt32($Matches[1], 16)
            if ($sec -eq 0) { Add-Result 'sleep' 'PC never goes to sleep' 'OK' 'Sleep is off' $null }
            else { Add-Result 'sleep' 'PC never goes to sleep' 'WARN' ('This PC goes to sleep after ' + [math]::Round($sec / 60) + ' minutes. Nobody can reach the shared folders while it sleeps.') 'NoSleep' }
        }
    }

    $out
}

# ---------------------------------------------------------------- UI
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$createdNew = $false
$script:mutex = New-Object System.Threading.Mutex($true, 'Local\ShareDoctorTray', [ref]$createdNew)
if (-not $createdNew) { exit }

$FixLabels = @{
    Creds = 'Re-enter the login'; Remap = 'Remap the drives'; HostsPin = 'Pin the name to the IP'
    ProfilePrivate = 'Set network to Private'; NoSleep = 'Stop the PC sleeping'
    ServerService = 'Start the Server service'; Firewall = 'Allow file sharing in the firewall'; Spooler = 'Restart printing and clear stuck jobs'; RestartSharing = 'Restart file sharing (no PC restart needed)'; ApplyAccess = 'Block PCs that are not allowed'; Guard = 'Turn on automatic repair'; Unshare = 'Stop sharing a folder'
}
$AdminFixes = @('HostsPin', 'ProfilePrivate', 'NoSleep', 'ServerService', 'Firewall', 'Spooler', 'RestartSharing', 'ApplyAccess', 'Guard', 'Unshare')
$FixOrder = @('ProfilePrivate', 'Firewall', 'ServerService', 'RestartSharing', 'ApplyAccess', 'Guard', 'Unshare', 'NoSleep', 'Spooler', 'HostsPin', 'Creds', 'Remap')

$AppIcoPath = Join-Path (Split-Path -Parent $PSCommandPath) 'ShareDoctor.ico'
function New-StatusIcon([System.Drawing.Color]$color) {
    $bmp = $null
    try { if (Test-Path $AppIcoPath) { $bmp = (New-Object System.Drawing.Icon($AppIcoPath, 32, 32)).ToBitmap() } } catch { }
    if (-not $bmp) { $bmp = New-Object System.Drawing.Bitmap 32, 32 }
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    $b = New-Object System.Drawing.SolidBrush $color
    $g.FillEllipse($b, 16, 16, 15, 15)
    $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::White), 2
    $g.DrawEllipse($pen, 16, 16, 15, 15)
    $g.Dispose()
    return [System.Drawing.Icon]::FromHandle($bmp.GetHicon())
}
$iconGreen  = New-StatusIcon ([System.Drawing.Color]::FromArgb(40, 167, 69))
$iconYellow = New-StatusIcon ([System.Drawing.Color]::FromArgb(240, 173, 0))
$iconRed    = New-StatusIcon ([System.Drawing.Color]::FromArgb(220, 53, 69))

$script:results   = @()
$script:overall   = 'OK'
$script:failStreak = 0
$script:alerted   = $false
$script:running   = $false
$script:exiting   = $false
$script:ps        = $null
$script:async     = $null
$script:lastCheck = $null

# ---- friendly look
$colBack   = [System.Drawing.Color]::FromArgb(244, 246, 248)
$colOk     = [System.Drawing.Color]::FromArgb(46, 160, 100)
$colWarn   = [System.Drawing.Color]::FromArgb(232, 163, 23)
$colFail   = [System.Drawing.Color]::FromArgb(214, 69, 80)
$colGrey   = [System.Drawing.Color]::FromArgb(150, 158, 168)
$colAccent = [System.Drawing.Color]::FromArgb(47, 128, 237)
$colText   = [System.Drawing.Color]::FromArgb(45, 55, 72)
$colLine   = [System.Drawing.Color]::FromArgb(210, 214, 220)
$glyphOk   = [string][char]0x2713
$glyphFail = [string][char]0x2715

function New-GlyphBitmap([System.Drawing.Color]$fill, [System.Drawing.Color]$glyphColor, [string]$glyph, [int]$size) {
    $bmp = New-Object System.Drawing.Bitmap $size, $size
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    $g.TextRenderingHint = 'AntiAlias'
    $g.Clear([System.Drawing.Color]::Transparent)
    $br = New-Object System.Drawing.SolidBrush $fill
    $g.FillEllipse($br, 1, 1, ($size - 3), ($size - 3))
    $f = New-Object System.Drawing.Font('Segoe UI Symbol', [single]($size * 0.45), [System.Drawing.FontStyle]::Bold, [System.Drawing.GraphicsUnit]::Pixel)
    $sf = New-Object System.Drawing.StringFormat
    $sf.Alignment = 'Center'
    $sf.LineAlignment = 'Center'
    $rect = New-Object System.Drawing.RectangleF 0, 0, $size, $size
    $gb = New-Object System.Drawing.SolidBrush $glyphColor
    $g.DrawString($glyph, $f, $gb, $rect, $sf)
    $g.Dispose()
    return $bmp
}

$imgs = New-Object System.Windows.Forms.ImageList
$imgs.ImageSize = New-Object System.Drawing.Size(26, 26)
$imgs.ColorDepth = 'Depth32Bit'
[void]$imgs.Images.Add((New-GlyphBitmap $colOk   ([System.Drawing.Color]::White) $glyphOk 26))
[void]$imgs.Images.Add((New-GlyphBitmap $colWarn ([System.Drawing.Color]::White) '!' 26))
[void]$imgs.Images.Add((New-GlyphBitmap $colFail ([System.Drawing.Color]::White) $glyphFail 26))
[void]$imgs.Images.Add((New-GlyphBitmap $colGrey ([System.Drawing.Color]::White) '-' 26))

# ---- main window
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Share Doctor'
$form.Size = New-Object System.Drawing.Size(860, 640)
$form.MinimumSize = New-Object System.Drawing.Size(740, 560)
$form.StartPosition = 'CenterScreen'
$form.BackColor = $colBack
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)
$brandIcon = $null
try { $icoPath = Join-Path (Split-Path -Parent $PSCommandPath) 'ShareDoctor.ico'; if (Test-Path $icoPath) { $brandIcon = New-Object System.Drawing.Icon $icoPath } } catch { }
if ($brandIcon) { $form.Icon = $brandIcon } else { $form.Icon = $iconGreen }

# big friendly banner at the top (changes colour with the status)
$banner = New-Object System.Windows.Forms.Panel
$banner.Dock = 'Top'
$banner.Height = 104
$banner.BackColor = $colGrey

$bannerIcon = New-Object System.Windows.Forms.PictureBox
$bannerIcon.Location = New-Object System.Drawing.Point(26, 24)
$bannerIcon.Size = New-Object System.Drawing.Size(56, 56)
$bannerIcon.BackColor = [System.Drawing.Color]::Transparent
$banner.Controls.Add($bannerIcon)

$header = New-Object System.Windows.Forms.Label
$header.Location = New-Object System.Drawing.Point(96, 16)
$header.Size = New-Object System.Drawing.Size(730, 36)
$header.Anchor = 'Top,Left,Right'
$header.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 17)
$header.ForeColor = [System.Drawing.Color]::White
$header.BackColor = [System.Drawing.Color]::Transparent
$header.Text = 'Checking...'
$banner.Controls.Add($header)

$sub = New-Object System.Windows.Forms.Label
$sub.Location = New-Object System.Drawing.Point(98, 54)
$sub.Size = New-Object System.Drawing.Size(730, 44)
$sub.Anchor = 'Top,Left,Right'
$sub.Font = New-Object System.Drawing.Font('Segoe UI', 10)
$sub.ForeColor = [System.Drawing.Color]::White
$sub.BackColor = [System.Drawing.Color]::Transparent
$banner.Controls.Add($sub)

$lv = New-Object System.Windows.Forms.ListView
$lv.Location = New-Object System.Drawing.Point(20, 120)
$lv.Size = New-Object System.Drawing.Size(814, 300)
$lv.Anchor = 'Top,Left,Right,Bottom'
$lv.View = 'Details'
$lv.HeaderStyle = 'None'
$lv.FullRowSelect = $true
$lv.GridLines = $false
$lv.HideSelection = $false
$lv.BorderStyle = 'None'
$lv.BackColor = [System.Drawing.Color]::White
$lv.ForeColor = $colText
$lv.SmallImageList = $imgs
[void]$lv.Columns.Add('Check', 330)
[void]$lv.Columns.Add('Details', 470)

$helpPanel = New-Object System.Windows.Forms.Panel
$helpPanel.Location = New-Object System.Drawing.Point(20, 430)
$helpPanel.Size = New-Object System.Drawing.Size(814, 74)
$helpPanel.Anchor = 'Left,Right,Bottom'
$helpPanel.BackColor = [System.Drawing.Color]::White
$helpPanel.Padding = New-Object System.Windows.Forms.Padding(12, 8, 12, 8)

$detail = New-Object System.Windows.Forms.TextBox
$detail.Dock = 'Fill'
$detail.Multiline = $true
$detail.ReadOnly = $true
$detail.BorderStyle = 'None'
$detail.BackColor = [System.Drawing.Color]::White
$detail.ForeColor = $colText
$detail.ScrollBars = 'Vertical'
$detail.Text = 'Click any line above to see the full explanation here.'
$helpPanel.Controls.Add($detail)

$stamp = New-Object System.Windows.Forms.Label
$stamp.Location = New-Object System.Drawing.Point(20, 566)
$stamp.Size = New-Object System.Drawing.Size(560, 22)
$stamp.Anchor = 'Left,Right,Bottom'
$credit = New-Object System.Windows.Forms.Label
$credit.Text = 'Share Doctor ' + $AppVersion + '  -  by Ekin Ozgur'
$credit.Location = New-Object System.Drawing.Point(590, 566)
$credit.Size = New-Object System.Drawing.Size(244, 22)
$credit.Anchor = 'Right,Bottom'
$credit.TextAlign = 'MiddleRight'
$credit.ForeColor = $colGrey
$credit.Cursor = [System.Windows.Forms.Cursors]::Hand
$stamp.ForeColor = $colGrey
$stamp.Font = New-Object System.Drawing.Font('Segoe UI', 9)

function New-Button($text, $x, $width, $primary) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text
    $b.Location = New-Object System.Drawing.Point($x, 516)
    $b.Size = New-Object System.Drawing.Size($width, 38)
    $b.Anchor = 'Left,Bottom'
    $b.FlatStyle = 'Flat'
    $b.Cursor = [System.Windows.Forms.Cursors]::Hand
    $b.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10)
    if ($primary) {
        $b.BackColor = $colAccent
        $b.ForeColor = [System.Drawing.Color]::White
        $b.FlatAppearance.BorderSize = 0
    } else {
        $b.BackColor = [System.Drawing.Color]::White
        $b.ForeColor = $colText
        $b.FlatAppearance.BorderColor = $colLine
        $b.FlatAppearance.BorderSize = 1
    }
    return $b
}
$btnFixAll   = New-Button 'Fix all problems' 20 150 $true
$btnFix      = New-Button 'Fix selected' 178 120 $false
$btnCheck    = New-Button 'Check now' 306 120 $false
$btnOpen     = New-Button 'Open folder' 434 120 $false
$btnSettings = New-Button 'Settings' 562 120 $false
$btnLog      = New-Button 'Activity' 690 120 $false

$form.Controls.Add($credit)
$form.Controls.AddRange(@($lv, $helpPanel, $btnFixAll, $btnFix, $btnCheck, $btnOpen, $btnSettings, $btnLog, $stamp, $banner))

# ---- tray
$notify = New-Object System.Windows.Forms.NotifyIcon
$notify.Icon = $iconGreen
$notify.Text = 'Share Doctor'
$notify.Visible = $true
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$miOpen  = $menu.Items.Add('Open Share Doctor')
$miCheck = $menu.Items.Add('Check now')
$miSettings = $menu.Items.Add('Settings')
$miFind = $menu.Items.Add('Look for new shared folders now')
$miUpdate = $menu.Items.Add('Check for updates')
$miAbout = $menu.Items.Add('About Share Doctor')
$miLog = $menu.Items.Add('Open the technical log')
$miExit  = $menu.Items.Add('Exit')
$notify.ContextMenuStrip = $menu

$ctx = New-Object System.Windows.Forms.ApplicationContext

# ---------------------------------------------------------------- helpers
function Get-Overall($res) {
    if (@($res | Where-Object { $_.Status -eq 'FAIL' }).Count -gt 0) { return 'FAIL' }
    if (@($res | Where-Object { $_.Status -eq 'WARN' }).Count -gt 0) { return 'WARN' }
    return 'OK'
}

function Resize-Columns {
    try {
        $lv.Columns[0].Width = 330
        $lv.Columns[1].Width = [Math]::Max(120, $lv.ClientSize.Width - 330 - 4)
    } catch { }
}

function Update-View {
    $lv.BeginUpdate()
    $lv.Items.Clear()
    foreach ($r in $script:results) {
        $it = New-Object System.Windows.Forms.ListViewItem([string]$r.Title)
        [void]$it.SubItems.Add([string]$r.Detail)
        $it.Tag = $r
        switch ($r.Status) {
            'OK'   { $it.ImageIndex = 0; $it.ForeColor = $colText }
            'WARN' { $it.ImageIndex = 1; $it.ForeColor = [System.Drawing.Color]::FromArgb(176, 112, 0) }
            'FAIL' { $it.ImageIndex = 2; $it.ForeColor = $colFail }
            default { $it.ImageIndex = 3; $it.ForeColor = $colGrey }
        }
        [void]$lv.Items.Add($it)
    }
    $lv.EndUpdate()
    Resize-Columns

    $firstFail = $script:results | Where-Object { $_.Status -eq 'FAIL' } | Select-Object -First 1
    $firstWarn = $script:results | Where-Object { $_.Status -eq 'WARN' } | Select-Object -First 1
    switch ($script:overall) {
        'OK' {
            $color = $colOk; $glyph = $glyphOk
            $header.Text = 'All good - your shared folders are working'
            $sub.Text = 'I will keep watching and tell you straight away if anything changes.'
        }
        'WARN' {
            $color = $colWarn; $glyph = '!'
            $header.Text = 'Working, but one thing needs a look'
            $sub.Text = ([string]$firstWarn.Title + ': ' + [string]$firstWarn.Detail)
        }
        default {
            $color = $colFail; $glyph = $glyphFail
            $header.Text = 'Cannot reach the shared folders'
            $sub.Text = ([string]$firstFail.Title + ': ' + [string]$firstFail.Detail)
        }
    }
    if ($sub.Text.Length -gt 200) { $sub.Text = $sub.Text.Substring(0, 197) + '...' }
    $banner.BackColor = $color
    if ($bannerIcon.Image) { $bannerIcon.Image.Dispose() }
    $bannerIcon.Image = New-GlyphBitmap ([System.Drawing.Color]::White) $color $glyph 56
    if ($script:lastCheck) {
        $stamp.Text = 'Last checked at ' + $script:lastCheck.ToString('h:mm:ss tt') + '  -  I check every ' + $cfg.CheckSeconds + ' seconds'
    }
}

function Show-Window {
    Update-View
    $form.Show()
    $form.WindowState = 'Normal'
    $form.Activate()
    $form.BringToFront()
}

# ---------------------------------------------------------------- automatic discovery of what other PCs share with this PC
$DiscoveredFile = Join-Path $env:LOCALAPPDATA 'ShareDoctor\discovered.json'
$script:syncPs = $null; $script:syncAsync = $null; $script:syncRunning = $false

$SyncScript = {
    param($subnet, $skip, $pw, $acct)
    function Run-Q([string]$exe, [string]$arguments, [int]$ms) {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $exe; $psi.Arguments = $arguments
        $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
        $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
        $p = [System.Diagnostics.Process]::Start($psi)
        $so = $p.StandardOutput.ReadToEndAsync(); $se = $p.StandardError.ReadToEndAsync()
        if (-not $p.WaitForExit($ms)) { try { $p.Kill() } catch { }; return @{ Out = ''; Exit = -1 } }
        return @{ Out = ($so.Result + $se.Result); Exit = $p.ExitCode }
    }
    $jobs = @()
    foreach ($i in 1..254) {
        $ip = $subnet + $i
        if ($skip -contains $ip) { continue }
        $c = New-Object System.Net.Sockets.TcpClient
        $jobs += [pscustomobject]@{ IP = $ip; Client = $c; Task = $c.ConnectAsync($ip, 445) }
    }
    Start-Sleep -Seconds 3
    $out = @()
    foreach ($j in $jobs) {
        $ok = ($j.Task.Status -eq 'RanToCompletion') -and $j.Client.Connected
        try { $j.Client.Close() } catch { }
        if (-not $ok) { continue }
        $ip = $j.IP; $name = ''
        try { $name = ([System.Net.Dns]::GetHostEntry($ip).HostName -split '\.')[0] } catch { }
        if (-not $name) {
            $r = Run-Q 'nbtstat.exe' ('-A ' + $ip) 8000
            foreach ($line in ($r.Out -split "`n")) { if ($line -match '^\s*(\S+)\s+<00>\s+UNIQUE') { $name = $Matches[1]; break } }
        }
        if (-not $name) { continue }
        $user = $name + '\' + $acct
        $ipc = '\\' + $ip + '\IPC$'
        [void](Run-Q 'net.exe' ('use "' + $ipc + '" /delete /y') 8000)
        $u = Run-Q 'net.exe' ('use "' + $ipc + '" "' + $pw + '" /user:"' + $user + '"') 15000
        if ($u.Exit -ne 0) { $out += [pscustomobject]@{ IP = $ip; Name = $name; User = $user; Access = 'denied'; Shares = @() }; continue }
        $v = Run-Q 'net.exe' ('view \\' + $ip) 15000
        [void](Run-Q 'net.exe' ('use "' + $ipc + '" /delete /y') 8000)
        $shares = @()
        foreach ($line in ($v.Out -split "`n")) {
            if ($line -match '^(\S.*?)\s{2,}Disk\b') { $n = $Matches[1].Trim(); if (-not $n.EndsWith('$')) { $shares += $n } }
        }
        $prs = @()
        foreach ($line in ($v.Out -split "`n")) {
            if ($line -match '^(\S.*?)\s{2,}Print\b') { $prs += $Matches[1].Trim() }
        }
        $out += [pscustomobject]@{ IP = $ip; Name = $name; User = $user; Access = 'ok'; Shares = @($shares); Printers = @($prs) }
    }
    return $out
}

function Get-Discovered {
    try { if (Test-Path -LiteralPath $DiscoveredFile) { return @(Get-Content -LiteralPath $DiscoveredFile -Raw | ConvertFrom-Json) } } catch { }
    return @()
}

function Merge-Discovered($c) {
    if ($c.AutoDiscover -eq $false) { return }
    $remotes = @($c.Remotes)
    foreach ($d in (Get-Discovered)) {
        $rm = @($remotes | Where-Object { [string]$_.IP -eq [string]$d.IP })[0]
        if (-not $rm) {
            $list = @(); foreach ($sn in @($d.Shares)) { $list += [pscustomobject]@{ Share = [string]$sn; Drive = $null } }
            $remotes += [pscustomobject]@{ Name = [string]$d.Name; IP = [string]$d.IP; User = [string]$d.User; Shares = @($list); Auto = $true }
        } else {
            $have = @(@($rm.Shares) | ForEach-Object { ([string]$_.Share).ToLower() })
            $shs = @($rm.Shares)
            foreach ($sn in @($d.Shares)) { if ($have -notcontains ([string]$sn).ToLower()) { $shs += [pscustomobject]@{ Share = [string]$sn; Drive = $null } } }
            $rm.Shares = @($shs)
        }
    }
    $c.Remotes = @($remotes)
}

$UserPwFile = Join-Path $env:LOCALAPPDATA 'ShareDoctor\sharepw.dat'
function Save-UserPassword([string]$pw) {
    try {
        $dir = Split-Path -Parent $UserPwFile
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        Set-Content -LiteralPath $UserPwFile -Value (ConvertFrom-SecureString (ConvertTo-SecureString $pw -AsPlainText -Force)) -Encoding ASCII
    } catch { Write-Log ('Could not store the password: ' + $_.Exception.Message) }
}
function Get-SharePassword {
    # stored encrypted for THIS Windows user (each Windows user types it once)
    foreach ($src in @('file', 'config')) {
        try {
            $enc = ''
            if ($src -eq 'file') { if (Test-Path -LiteralPath $UserPwFile) { $enc = (Get-Content -LiteralPath $UserPwFile -Raw).Trim() } }
            else { $enc = [string]$cfg.SharePwProtected }
            if (-not $enc) { continue }
            $sec = ConvertTo-SecureString $enc
            $pw = ([System.Net.NetworkCredential]::new('', $sec)).Password
            if ($pw) { return $pw }
        } catch { }
    }
    return ''
}

function Start-Sync {
    if ($script:syncRunning -or $cfg.AutoDiscover -eq $false) { return }
    $pw = Get-SharePassword
    if (-not $pw) { return }
    $skip = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | ForEach-Object { $_.IPAddress })
    $skip += [string]$cfg.Gateway
    $acct = ([string]$cfg.ShareUser -split '\\')[-1]
    try {
        $script:syncRunning = $true
        $script:syncPs = [powershell]::Create()
        [void]$script:syncPs.AddScript($SyncScript.ToString()).AddArgument([string]$cfg.ExpectedSubnet).AddArgument($skip).AddArgument($pw).AddArgument($acct)
        $script:syncAsync = $script:syncPs.BeginInvoke()
    } catch { $script:syncRunning = $false; Write-Log ('Could not start the PC search: ' + $_.Exception.Message) }
}

function Complete-Sync {
    $res = @()
    try { $res = @($script:syncPs.EndInvoke($script:syncAsync)) } catch { Write-Log ('PC search error: ' + $_.Exception.Message) }
    try { $script:syncPs.Dispose() } catch { }
    $script:syncRunning = $false
    $store = @(Get-Discovered)
    $news = @()
    $pw = Get-SharePassword
    foreach ($r in $res) {
        $old = @($store | Where-Object { [string]$_.IP -eq [string]$r.IP })[0]
        $store = @($store | Where-Object { [string]$_.IP -ne [string]$r.IP })
        if ($r.Access -ne 'ok' -or (@($r.Shares).Count -eq 0 -and @($r.Printers).Count -eq 0)) { continue }
        $store += [pscustomobject]@{ IP = [string]$r.IP; Name = [string]$r.Name; User = [string]$r.User; Shares = @($r.Shares); Printers = @($r.Printers) }
        $oldShares = @(); if ($old) { $oldShares = @($old.Shares) }
        foreach ($sn in @($r.Shares)) { if ($oldShares -notcontains $sn) { $news += ($sn + ' on ' + $r.Name) } }
        if (-not $old -and $pw) {
            foreach ($t in @([string]$r.Name, [string]$r.IP)) {
                [void](Run-Quiet 'cmdkey.exe' ('/delete:"' + $t + '"'))
                [void](Run-Quiet 'cmdkey.exe' ('/add:"' + $t + '" /user:"' + [string]$r.User + '" /pass:"' + $pw + '"'))
            }
        }
    }
    try {
        $dir = Split-Path -Parent $DiscoveredFile
        if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        ConvertTo-Json -InputObject @($store) -Depth 6 | Set-Content -LiteralPath $DiscoveredFile -Encoding UTF8
    } catch { Write-Log ('Could not save the found folders: ' + $_.Exception.Message) }
    if ($news.Count -gt 0) {
        Write-Log ('Found shared folders: ' + ($news -join '; '))
        try { $notify.ShowBalloonTip(6000, 'Share Doctor', ('New shared folders found: ' + ($news -join ', ')), 'Info') } catch { }
        Start-Check
    }
}

function Start-Check {
    if ($script:running) { return }
    try { $newCfg = Read-Config; if ($newCfg) { Merge-Discovered $newCfg; $script:cfg = $newCfg; $cfg = $newCfg } } catch { Write-Log "Settings file problem: $($_.Exception.Message)" }
    $script:running = $true
    try {
        $script:ps = [powershell]::Create()
        [void]$script:ps.AddScript($CheckScript.ToString()).AddArgument($cfg)
        $script:async = $script:ps.BeginInvoke()
    } catch {
        $script:running = $false
        Write-Log "Could not start check: $($_.Exception.Message)"
    }
}

$script:healAt = @{}
$script:askedPw = $false
function Heal-Creds([string[]]$names) {
    # silently re-saves the login when Windows lost it or it stopped working, so no password box pops up in other programs
    $did = $false
    foreach ($n in $names) {
        $rm = Get-Remote $n
        if (-not $rm) { continue }
        if ($script:healAt.ContainsKey($n) -and (((Get-Date) - $script:healAt[$n]).TotalMinutes -lt 10)) { continue }
        $script:healAt[$n] = Get-Date
        $pw = Get-SharePassword
        if (-not $pw -and -not $script:askedPw) {
            $script:askedPw = $true
            $pw = Ask-Password ('Share Doctor needs the sharing password once for this Windows user (to open folders on ' + $rm.Name + ')')
            if ($pw) { Save-UserPassword $pw }
        }
        if (-not $pw) { continue }
        foreach ($t in @([string]$rm.Name, [string]$rm.IP)) {
            [void](Run-Quiet 'cmdkey.exe' ('/delete:"' + $t + '"'))
            [void](Run-Quiet 'cmdkey.exe' ('/add:"' + $t + '" /user:"' + [string]$rm.User + '" /pass:"' + $pw + '"'))
        }
        Write-Log ('Login for ' + $rm.Name + ' was missing or refused - saved it again automatically')
        $did = $true
    }
    if ($did) { $quickTimer.Start() }
}

function Complete-Check {
    $script:lastCheck = Get-Date
    $prev = $script:overall
    $overall = Get-Overall $script:results
    $script:overall = $overall

    switch ($overall) { 'OK' { $ico = $iconGreen } 'WARN' { $ico = $iconYellow } default { $ico = $iconRed } }
    $notify.Icon = $ico
    if (-not $brandIcon) { $form.Icon = $ico }

    $problems = @($script:results | Where-Object { $_.Status -eq 'FAIL' -or $_.Status -eq 'WARN' })
    $tip = 'Share Doctor: all OK'
    if ($problems.Count -gt 0) { $tip = 'Share Doctor: ' + $problems[0].Title }
    if ($tip.Length -gt 62) { $tip = $tip.Substring(0, 62) }
    $notify.Text = $tip

    Update-View

    try {
        $credNames = @($script:results | Where-Object { $_.Status -ne 'OK' -and $_.Status -ne 'SKIP' -and ([string]$_.Fix) -like 'Creds:*' } | ForEach-Object { ([string]$_.Fix).Substring(6) } | Select-Object -Unique)
        if ($credNames.Count -gt 0) { Heal-Creds $credNames }
    } catch { Write-Log ('Auto-login error: ' + $_.Exception.Message) }

    if ($prev -ne $overall) {
        Write-Log ('Status ' + $prev + ' -> ' + $overall + ': ' + (($problems | ForEach-Object { $_.Title + ' [' + $_.Detail + ']' }) -join '; '))
    }

    if ($overall -eq 'FAIL') {
        $script:failStreak++
        if ($script:failStreak -eq 1) {
            $quickTimer.Start()                      # double-check in a few seconds before alerting
        } elseif (-not $script:alerted) {
            $script:alerted = $true
            $first = $script:results | Where-Object { $_.Status -eq 'FAIL' } | Select-Object -First 1
            $txt = $first.Title + ': ' + $first.Detail
            if ($txt.Length -gt 240) { $txt = $txt.Substring(0, 240) }
            $notify.ShowBalloonTip(10000, 'Shared folder problem', $txt, [System.Windows.Forms.ToolTipIcon]::Error)
            if ($cfg.PopupOnFail) { Show-Window }
        }
    } else {
        if ($script:alerted) {
            $notify.ShowBalloonTip(5000, 'Share Doctor', 'The shared folders are back.', [System.Windows.Forms.ToolTipIcon]::Info)
        }
        $script:failStreak = 0
        $script:alerted = $false
    }
}

function Ask-Password([string]$prompt) {
    $f = New-Object System.Windows.Forms.Form
    if ($brandIcon) { $f.Icon = $brandIcon }
    $f.Text = 'Share Doctor'
    $f.Size = New-Object System.Drawing.Size(420, 170)
    $f.StartPosition = 'CenterScreen'
    $f.FormBorderStyle = 'FixedDialog'
    $f.MaximizeBox = $false; $f.MinimizeBox = $false; $f.TopMost = $true
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $prompt; $l.Location = New-Object System.Drawing.Point(12, 14); $l.Size = New-Object System.Drawing.Size(380, 20)
    $t = New-Object System.Windows.Forms.TextBox
    $t.UseSystemPasswordChar = $true; $t.Location = New-Object System.Drawing.Point(12, 42); $t.Size = New-Object System.Drawing.Size(380, 24)
    $ok = New-Object System.Windows.Forms.Button
    $ok.Text = 'Save'; $ok.Location = New-Object System.Drawing.Point(222, 84); $ok.Size = New-Object System.Drawing.Size(80, 30); $ok.DialogResult = 'OK'
    $cn = New-Object System.Windows.Forms.Button
    $cn.Text = 'Cancel'; $cn.Location = New-Object System.Drawing.Point(312, 84); $cn.Size = New-Object System.Drawing.Size(80, 30); $cn.DialogResult = 'Cancel'
    $f.Controls.AddRange(@($l, $t, $ok, $cn)); $f.AcceptButton = $ok; $f.CancelButton = $cn
    $res = $f.ShowDialog()
    $pw = $t.Text
    $f.Dispose()
    if ($res -eq 'OK' -and $pw) { return $pw }
    return $null
}

function Get-Remote([string]$name) {
    return @($cfg.Remotes | Where-Object { [string]$_.Name -eq $name })[0]
}

function Run-Quiet([string]$exe, [string]$arguments) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $exe; $psi.Arguments = $arguments
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $p = [System.Diagnostics.Process]::Start($psi)
    $out = $p.StandardOutput.ReadToEnd() + $p.StandardError.ReadToEnd()
    $p.WaitForExit()
    $script:LastExit = $p.ExitCode
    return $out
}

function Fix-Creds([string]$remoteName) {
    $rm = Get-Remote $remoteName
    if (-not $rm) { return }
    $u = [string]$rm.User
    $pw = Ask-Password ('Password for ' + $u + ' (on ' + $rm.Name + ')')
    if (-not $pw) { return }
    Save-UserPassword $pw
    foreach ($t in @([string]$rm.Name, [string]$rm.IP)) {
        [void](Run-Quiet 'cmdkey.exe' ('/delete:"' + $t + '"'))
        [void](Run-Quiet 'cmdkey.exe' ('/add:"' + $t + '" /user:"' + $u + '" /pass:"' + $pw + '"'))
    }
    Write-Log "Saved login $u for $($rm.Name)"
}

function Fix-Remap([string]$remoteName) {
    $rm = Get-Remote $remoteName
    if (-not $rm) { return }
    $problems = @()
    foreach ($s in @($rm.Shares)) {
        if (-not $s.Drive) { continue }
        $d = $s.Drive
        $unc = "\\$($rm.IP)\$($s.Share)"
        [void](Run-Quiet 'net.exe' ('use ' + $d + ' /delete /y'))
        $o = (Run-Quiet 'net.exe' ('use ' + $d + ' "' + $unc + '" /persistent:yes')).Trim()
        Write-Log "net use $d $unc -> $o"
        if ($script:LastExit -ne 0) { $problems += "$d : $o" }
    }
    if ($problems.Count -gt 0) {
        [void][System.Windows.Forms.MessageBox]::Show(($problems -join "`n`n"), 'Share Doctor - could not map a drive')
    }
}

function Start-Elevated([string[]]$psArgs, [bool]$wait) {
    # runs this script again as administrator with NO window at all (through a tiny hidden script host)
    $vbsText = @'
Set sh = CreateObject("WScript.Shell")
cmd = "powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & WScript.Arguments(0) & """"
For i = 1 To WScript.Arguments.Count - 1
  a = WScript.Arguments(i)
  If Left(a, 1) = "-" Then
    cmd = cmd & " " & a
  Else
    cmd = cmd & " """ & a & """"
  End If
Next
WScript.Quit sh.Run(cmd, 0, True)
'@
    $dir = Join-Path $env:LOCALAPPDATA 'ShareDoctor'
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $vbs = Join-Path $dir 'RunHidden.vbs'
    $cur = ''
    if (Test-Path -LiteralPath $vbs) { $cur = [System.IO.File]::ReadAllText($vbs) }
    if ($cur -ne $vbsText) { [System.IO.File]::WriteAllText($vbs, $vbsText, [System.Text.Encoding]::ASCII) }
    $a = '"' + $vbs + '" "' + $PSCommandPath + '"'
    foreach ($x in $psArgs) { if ($x.StartsWith('-')) { $a += ' ' + $x } else { $a += ' "' + $x + '"' } }
    if ($wait) { Start-Process -FilePath 'wscript.exe' -ArgumentList $a -Verb RunAs -Wait }
    else { Start-Process -FilePath 'wscript.exe' -ArgumentList $a -Verb RunAs }
}

function Start-AdminFix([string[]]$names, [string]$proposal = '') {
    $psa = @('-Fix', ($names -join ','), '-ConfigPath', $ConfigPath)
    if ($proposal) { $psa += @('-Proposal', $proposal) }
    try { Start-Elevated $psa $true; return $true }
    catch { Write-Log "Admin fix cancelled or failed: $($_.Exception.Message)"; return $false }
}

function Do-Fix([string[]]$ids) {
    $ids = @($ids | Where-Object { $_ } | Select-Object -Unique)
    if ($ids.Count -eq 0) { return }
    $ordered = @()
    foreach ($b in $FixOrder) { $ordered += @($ids | Where-Object { (($_ -split ':')[0]) -eq $b }) }
    $admin = @($ordered | Where-Object { $AdminFixes -contains (($_ -split ':')[0]) })
    if ($admin.Count -gt 0) {
        $resFile = Join-Path $env:ProgramData 'ShareDoctor\fix-result.txt'
        Remove-Item -LiteralPath $resFile -Force -ErrorAction SilentlyContinue
        $asked = Start-AdminFix $admin
        if ($asked) {
            $res = @()
            if (Test-Path -LiteralPath $resFile) { $res = @(Get-Content -LiteralPath $resFile) }
            $failed = @($res | Where-Object { $_ -like 'FAILED*' })
            if ($res.Count -eq 0) {
                [void][System.Windows.Forms.MessageBox]::Show('Windows did not run the repair. If you saw a permission question, say Yes. If your antivirus (Norton) blocked it, allow the folder C:\ShareDoctor and try again.', 'Share Doctor')
            } elseif ($failed.Count -gt 0) {
                [void][System.Windows.Forms.MessageBox]::Show(("This could not be fixed:`n`n" + ($failed -join "`n")), 'Share Doctor')
            }
        }
    }
    foreach ($id in $ordered) {
        $parts = $id -split ':', 2
        if ($parts[0] -eq 'Creds') { Fix-Creds $parts[1] }
        if ($parts[0] -eq 'Remap') { Fix-Remap $parts[1] }
    }
    Start-Check
}

# ---------------------------------------------------------------- updates
function Read-UpdateText([string]$src, [string]$name) {
    if ($src -match '^https?://') {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $u = $src.TrimEnd('/') + '/' + $name + '?t=' + [DateTime]::UtcNow.Ticks
        $r = Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 15 -Headers @{ 'Cache-Control' = 'no-cache'; 'Pragma' = 'no-cache' }
        return [string]$r.Content
    }
    return [System.IO.File]::ReadAllText((Join-Path $src $name))
}

function Get-UpdateInfo {
    $src = [string]$cfg.UpdateSource
    if (-not $src) { return $null }
    $info = (Read-UpdateText $src 'version.json') | ConvertFrom-Json
    $newer = $false
    try { $newer = ([version][string]$info.version) -gt ([version]$AppVersion) } catch { }
    return [pscustomobject]@{ Version = [string]$info.version; Sha256 = ([string]$info.sha256).ToLower(); File = $(if ($info.file) { [string]$info.file } else { 'ShareDoctor.zip' }); Notes = [string]$info.notes; Newer = $newer }
}

function Install-Update($info) {
    $src = [string]$cfg.UpdateSource
    $work = Join-Path $env:TEMP ('sharedoctor-update-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $work | Out-Null
    $zip = Join-Path $work 'update.zip'
    if ($src -match '^https?://') {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri ($src.TrimEnd('/') + '/' + $info.File + '?t=' + [DateTime]::UtcNow.Ticks) -OutFile $zip -UseBasicParsing -TimeoutSec 60 -Headers @{ 'Cache-Control' = 'no-cache' }
    } else { Copy-Item -LiteralPath (Join-Path $src $info.File) -Destination $zip }
    $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLower()
    if ($info.Sha256 -and $hash -ne $info.Sha256) { throw 'The downloaded update does not match its checksum. Nothing was changed.' }
    if (-not $info.Sha256) { throw 'The update has no checksum. Nothing was changed.' }
    $ex = Join-Path $work 'files'
    Expand-Archive -LiteralPath $zip -DestinationPath $ex -Force
    $inner = Get-ChildItem -LiteralPath $ex -Filter 'ShareDoctor.ps1' -Recurse | Select-Object -First 1
    if (-not $inner) { throw 'The update file is not a Share Doctor package.' }
    $errs = $null; $tok = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($inner.FullName, [ref]$tok, [ref]$errs)
    if ($errs -and $errs.Count -gt 0) { throw 'The update file is damaged. Nothing was changed.' }
    Start-Elevated @('-Update', $inner.DirectoryName, '-ConfigPath', $ConfigPath) $false
    Write-Log ('Update to ' + $info.Version + ' started')
    $script:exiting = $true
    $notify.Visible = $false
    $notify.Dispose()
    $ctx.ExitThread()
}

function Check-Update([bool]$manual) {
    try {
        if (-not [string]$cfg.UpdateSource) {
            if ($manual) { [void][System.Windows.Forms.MessageBox]::Show('No update source is set yet. Open Settings, tab "This PC", and fill in "Update source".', 'Share Doctor') }
            return
        }
        $info = Get-UpdateInfo
        if ($info -and $info.Newer) {
            $msg = 'A new version of Share Doctor is ready: ' + $info.Version + ' (you have ' + $AppVersion + ').'
            if ($info.Notes) { $msg += "`n`n" + $info.Notes }
            $msg += "`n`nUpdate now? Your settings are kept. Share Doctor restarts by itself."
            if ([System.Windows.Forms.MessageBox]::Show($msg, 'Share Doctor - update', 'YesNo', 'Information') -eq 'Yes') { Install-Update $info }
        } elseif ($manual) {
            [void][System.Windows.Forms.MessageBox]::Show('You have the newest version (' + $AppVersion + ').', 'Share Doctor')
        }
    } catch {
        Write-Log ('Update check failed: ' + $_.Exception.Message)
        if ($manual) { [void][System.Windows.Forms.MessageBox]::Show('Could not check for updates: ' + $_.Exception.Message, 'Share Doctor') }
    }
}

# ---------------------------------------------------------------- find PCs on the network
function Find-Pcs([string]$subnet, [scriptblock]$progress) {
    $mine = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | ForEach-Object { $_.IPAddress })
    $jobs = @()
    foreach ($i in 1..254) {
        $ip = $subnet + $i
        if ($mine -contains $ip -or $ip -eq [string]$cfg.Gateway) { continue }
        $c = New-Object System.Net.Sockets.TcpClient
        $jobs += [pscustomobject]@{ IP = $ip; Client = $c; Task = $c.ConnectAsync($ip, 445) }
    }
    $until = (Get-Date).AddSeconds(3)
    while ((Get-Date) -lt $until) {
        if ($progress) { & $progress 'Looking for PCs...' }
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 100
    }
    $found = @()
    foreach ($j in $jobs) {
        $ok = ($j.Task.Status -eq 'RanToCompletion') -and $j.Client.Connected
        try { $j.Client.Close() } catch { }
        if ($ok) { $found += [pscustomobject]@{ IP = $j.IP; Name = '' } }
    }
    foreach ($f in $found) {
        if ($progress) { & $progress ('Reading the name of ' + $f.IP + '...') }
        [System.Windows.Forms.Application]::DoEvents()
        try { $f.Name = ([System.Net.Dns]::GetHostEntry($f.IP).HostName -split '\.')[0] } catch { }
        if (-not $f.Name) {
            try {
                $o = Run-Quiet 'nbtstat.exe' ('-A ' + $f.IP)
                foreach ($line in ($o -split "`n")) { if ($line -match '^\s*(\S+)\s+<00>\s+UNIQUE') { $f.Name = $Matches[1]; break } }
            } catch { }
        }
        if (-not $f.Name) { $f.Name = '(name not found)' }
    }
    return @($found)
}

function Get-RemoteShares([string]$ip, [string]$user, [string]$pw) {
    # returns @{ Ok = $true/$false; Shares = @(names); Error = '' }
    $res = @{ Ok = $false; Shares = @(); Error = '' }
    $ipc = '\\' + $ip + '\IPC$'
    [void](Run-Quiet 'net.exe' ('use "' + $ipc + '" /delete /y'))
    if ($pw) {
        $o = (Run-Quiet 'net.exe' ('use "' + $ipc + '" "' + $pw + '" /user:"' + $user + '"')).Trim()
        if ($script:LastExit -ne 0) { $res.Error = $o; return $res }
    }
    $v = Run-Quiet 'net.exe' ('view \\' + $ip)
    $vExit = $script:LastExit
    if ($pw) { [void](Run-Quiet 'net.exe' ('use "' + $ipc + '" /delete /y')) }
    if ($vExit -ne 0) { $res.Error = $v.Trim(); return $res }
    foreach ($line in ($v -split "`n")) {
        if ($line -match '^(\S.*?)\s{2,}Disk\b') {
            $n = $Matches[1].Trim()
            if (-not $n.EndsWith('$')) { $res.Shares += $n }
        }
    }
    $res.Ok = $true
    return $res
}

function Show-ShareManager {
    # returns the names that were stopped
    $dlg = New-Object System.Windows.Forms.Form
    if ($brandIcon) { $dlg.Icon = $brandIcon }
    $dlg.Text = 'Shares on this PC'
    $dlg.Size = New-Object System.Drawing.Size(800, 500)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.BackColor = $colBack
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $dlg.Controls.Add((New-Label 'Every folder this PC shares right now. Tick the ones to STOP sharing. Your folders and files are never deleted - other PCs just cannot open the share any more.' 16 10 750 44))
    $list = New-Object System.Windows.Forms.ListView
    $list.View = 'Details'; $list.CheckBoxes = $true; $list.FullRowSelect = $true
    $list.Location = New-Object System.Drawing.Point(16, 60)
    $list.Size = New-Object System.Drawing.Size(750, 320)
    [void]$list.Columns.Add('Shared as', 190)
    [void]$list.Columns.Add('Folder on this PC', 300)
    [void]$list.Columns.Add('Note', 240)
    $dlg.Controls.Add($list)
    $rows = @(Get-CimInstance Win32_Share -ErrorAction SilentlyContinue | Where-Object { $_.Type -eq 0 -and $_.Path } | Sort-Object Path, Name)
    $mine = @(@($cfg.LocalShares) | ForEach-Object { ([string]$_.Share).ToLower() })
    foreach ($r in $rows) {
        $same = @($rows | Where-Object { $_.Name -ne $r.Name -and ([string]$_.Path).TrimEnd('\').ToLower() -eq ([string]$r.Path).TrimEnd('\').ToLower() } | ForEach-Object { $_.Name })
        $note = ''
        if ($same.Count -gt 0) { $note = 'Same folder as: ' + ($same -join ', ') }
        if ($mine -contains ([string]$r.Name).ToLower()) { if ($note) { $note += '  (made by Share Doctor)' } else { $note = 'Made by Share Doctor' } }
        $it = New-Object System.Windows.Forms.ListViewItem([string]$r.Name)
        [void]$it.SubItems.Add([string]$r.Path)
        [void]$it.SubItems.Add($note)
        if ($same.Count -gt 0) { $it.ForeColor = [System.Drawing.Color]::FromArgb(180, 90, 0) }
        [void]$list.Items.Add($it)
    }
    $script:removedShares = @()
    $script:adoptShares = @()
    $btnStop = New-Object System.Windows.Forms.Button
    $btnStop.Text = 'Stop sharing the ticked ones'
    $btnStop.Location = New-Object System.Drawing.Point(16, 400)
    $btnStop.Size = New-Object System.Drawing.Size(250, 36)
    $btnStop.Add_Click({
        $names = @($list.CheckedItems | ForEach-Object { $_.Text })
        if ($names.Count -eq 0) { [void][System.Windows.Forms.MessageBox]::Show('Tick at least one share first.', 'Share Doctor'); return }
        $ans = [System.Windows.Forms.MessageBox]::Show(("Stop sharing:`n`n" + ($names -join "`n") + "`n`nThe folders and files stay where they are. Any PC or drive using these shares loses access. Continue?"), 'Share Doctor', 'YesNo', 'Warning')
        if ($ans -ne 'Yes') { return }
        $ids = @()
        foreach ($n in $names) { $hex = (([System.Text.Encoding]::UTF8.GetBytes($n) | ForEach-Object { $_.ToString('x2') }) -join ''); $ids += ('Unshare:' + $hex) }
        $resFile = Join-Path $env:ProgramData 'ShareDoctor\fix-result.txt'
        Remove-Item -LiteralPath $resFile -Force -ErrorAction SilentlyContinue
        if (-not (Start-AdminFix $ids)) { return }
        $res = @(); if (Test-Path -LiteralPath $resFile) { $res = @(Get-Content -LiteralPath $resFile) }
        $failed = @($res | Where-Object { $_ -like 'FAILED*' })
        if ($res.Count -eq 0) { [void][System.Windows.Forms.MessageBox]::Show('Windows did not run the change. Nothing was removed.', 'Share Doctor'); return }
        if ($failed.Count -gt 0) { [void][System.Windows.Forms.MessageBox]::Show(("Some could not be removed:`n`n" + ($failed -join "`n")), 'Share Doctor') }
        foreach ($it in @($list.CheckedItems)) {
            $nm = $it.Text
            if (-not ($failed | Where-Object { $_ -like ('*' + $nm + '*') })) { $script:removedShares += $nm; $list.Items.Remove($it) }
        }
    })
    $btnAdopt = New-Object System.Windows.Forms.Button
    $btnAdopt.Text = 'Let Share Doctor manage the ticked ones'
    $btnAdopt.Location = New-Object System.Drawing.Point(276, 400)
    $btnAdopt.Size = New-Object System.Drawing.Size(380, 36)
    $btnAdopt.Add_Click({
        $picked = @($list.CheckedItems)
        if ($picked.Count -eq 0) { [void][System.Windows.Forms.MessageBox]::Show('Tick at least one share first.', 'Share Doctor'); return }
        $ans = [System.Windows.Forms.MessageBox]::Show("Share Doctor will check these shares and, when you click Save, limit them to the sharing account (the 'Everyone' access is removed).`n`nPCs or programs that open them with another login will be refused. Continue?", 'Share Doctor', 'YesNo', 'Warning')
        if ($ans -ne 'Yes') { return }
        foreach ($it in $picked) { $script:adoptShares += [pscustomobject]@{ Share = $it.Text; Path = $it.SubItems[1].Text } }
        [void][System.Windows.Forms.MessageBox]::Show('Added. Click Close, then Save in Settings.', 'Share Doctor')
    })
    $dlg.Controls.Add($btnAdopt)
    $btnClose = New-Object System.Windows.Forms.Button
    $btnClose.Text = 'Close'
    $btnClose.Location = New-Object System.Drawing.Point(666, 400)
    $btnClose.Size = New-Object System.Drawing.Size(100, 36)
    $btnClose.DialogResult = 'OK'
    $dlg.Controls.Add($btnStop); $dlg.Controls.Add($btnClose)
    [void]$dlg.ShowDialog()
    $dlg.Dispose()
    return @($script:removedShares)
}

function Get-WindowsPrinterList {
    $out = @()
    try {
        foreach ($p in @(Get-Printer -ErrorAction Stop)) {
            $n = [string]$p.Name; $port = [string]$p.PortName
            if ($n -match '^(Microsoft Print to PDF|Microsoft XPS Document Writer|OneNote|Send To OneNote|Fax)' -or $port -match '^(PORTPROMPT|nul|FILE|XPSPort|SHRFAX)') { continue }
            $ip = ''
            try { $pp = Get-PrinterPort -Name $port -ErrorAction Stop; if ($pp.PrinterHostAddress) { $ip = [string]$pp.PrinterHostAddress } } catch { }
            $src = 'Printer on this PC'
            if ($n.StartsWith('\\')) { $src = 'Shared printer (connected)' } elseif ($p.Shared) { $src = 'Printer on this PC (shared)' }
            $out += [pscustomobject]@{ Name = $n; IP = $ip; Source = $src }
        }
    } catch { }
    return @($out)
}

function Find-NetworkPrinters([string]$subnet, [scriptblock]$progress) {
    $mine = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | ForEach-Object { $_.IPAddress })
    $jobs = @()
    foreach ($i in 1..254) {
        $ip = $subnet + $i
        if ($mine -contains $ip -or $ip -eq [string]$cfg.Gateway) { continue }
        $c = New-Object System.Net.Sockets.TcpClient
        $jobs += [pscustomobject]@{ IP = $ip; Client = $c; Task = $c.ConnectAsync($ip, 9100) }
    }
    $until = (Get-Date).AddSeconds(3)
    while ((Get-Date) -lt $until) { if ($progress) { & $progress 'Looking for network printers...' }; [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100 }
    $found = @()
    foreach ($j in $jobs) {
        $ok = ($j.Task.Status -eq 'RanToCompletion') -and $j.Client.Connected
        try { $j.Client.Close() } catch { }
        if ($ok) {
            $nm = ''
            try { $nm = ([System.Net.Dns]::GetHostEntry($j.IP).HostName -split '\.')[0] } catch { }
            if (-not $nm) { $nm = 'Network printer ' + $j.IP }
            $found += [pscustomobject]@{ Name = $nm; IP = $j.IP; Source = 'Network printer' }
        }
    }
    return @($found)
}

function Show-PrinterPicker {
    $dlg = New-Object System.Windows.Forms.Form
    if ($brandIcon) { $dlg.Icon = $brandIcon }
    $dlg.Text = 'Find printers'
    $dlg.Size = New-Object System.Drawing.Size(820, 520)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.BackColor = $colBack
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $status = New-Label 'Looking for printers...' 16 12 770 24
    $dlg.Controls.Add($status)
    $list = New-Object System.Windows.Forms.ListView
    $list.View = 'Details'; $list.CheckBoxes = $true; $list.FullRowSelect = $true
    $list.Location = New-Object System.Drawing.Point(16, 44)
    $list.Size = New-Object System.Drawing.Size(770, 360)
    [void]$list.Columns.Add('Printer', 330)
    [void]$list.Columns.Add('Address', 130)
    [void]$list.Columns.Add('Where it is', 290)
    $dlg.Controls.Add($list)
    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text = 'Watch the ticked printers'
    $btnOk.Location = New-Object System.Drawing.Point(16, 424)
    $btnOk.Size = New-Object System.Drawing.Size(210, 36)
    $btnOk.DialogResult = 'OK'
    $btnConn = New-Object System.Windows.Forms.Button
    $btnConn.Text = 'Connect ticked shared printers'
    $btnConn.Location = New-Object System.Drawing.Point(236, 424)
    $btnConn.Size = New-Object System.Drawing.Size(240, 36)
    $btnConn.Add_Click({
        $msgs = @()
        foreach ($it in @($list.CheckedItems)) {
            if ($it.SubItems[2].Text -like 'Shared by*') {
                try { Add-Printer -ConnectionName $it.Text -ErrorAction Stop; $msgs += ('Connected ' + $it.Text) }
                catch { $msgs += ('Could not connect ' + $it.Text + ': ' + $_.Exception.Message) }
            }
        }
        if ($msgs.Count -eq 0) { $msgs = @('Tick a printer that says "Shared by ..." first.') }
        [void][System.Windows.Forms.MessageBox]::Show(($msgs -join "`n"), 'Share Doctor')
    })
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'Cancel'
    $btnCancel.Location = New-Object System.Drawing.Point(686, 424)
    $btnCancel.Size = New-Object System.Drawing.Size(100, 36)
    $btnCancel.DialogResult = 'Cancel'
    $dlg.Controls.Add($btnOk); $dlg.Controls.Add($btnConn); $dlg.Controls.Add($btnCancel)
    $script:printerPick = @()
    $dlg.Add_Shown({
        $dlg.Refresh()
        $all = @(Get-WindowsPrinterList)
        foreach ($d in (Get-Discovered)) {
            foreach ($pn in @($d.Printers)) { $all += [pscustomobject]@{ Name = ('\\' + [string]$d.Name + '\' + [string]$pn); IP = ''; Source = ('Shared by ' + [string]$d.Name) } }
        }
        $net = @()
        try { $net = @(Find-NetworkPrinters ([string]$cfg.ExpectedSubnet) { param($t) $status.Text = $t; $status.Refresh() }) } catch { }
        $knownIps = @($all | ForEach-Object { $_.IP } | Where-Object { $_ })
        foreach ($n in $net) { if ($knownIps -notcontains $n.IP) { $all += $n } }
        foreach ($x in $all) {
            $it = New-Object System.Windows.Forms.ListViewItem([string]$x.Name)
            [void]$it.SubItems.Add([string]$x.IP)
            [void]$it.SubItems.Add([string]$x.Source)
            [void]$list.Items.Add($it)
        }
        if ($all.Count -eq 0) { $status.Text = 'No printers found.' } else { $status.Text = ('Found ' + $all.Count + ' printer(s). Tick the ones to watch.') }
    })
    if ($dlg.ShowDialog() -eq 'OK') {
        $script:printerPick = @($list.CheckedItems | ForEach-Object { [pscustomobject]@{ Name = $_.Text; IP = $_.SubItems[1].Text; Source = $_.SubItems[2].Text } })
    }
    $dlg.Dispose()
    return @($script:printerPick)
}

function Show-About {
    $dlg = New-Object System.Windows.Forms.Form
    if ($brandIcon) { $dlg.Icon = $brandIcon }
    $dlg.Text = 'About Share Doctor'
    $dlg.Size = New-Object System.Drawing.Size(460, 360)
    $dlg.StartPosition = 'CenterScreen'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.BackColor = [System.Drawing.Color]::White
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    if ($brandIcon) {
        $pb = New-Object System.Windows.Forms.PictureBox
        $pb.Image = (New-Object System.Drawing.Icon($brandIcon, 64, 64)).ToBitmap()
        $pb.SizeMode = 'Zoom'
        $pb.Location = New-Object System.Drawing.Point(180, 20)
        $pb.Size = New-Object System.Drawing.Size(80, 80)
        $dlg.Controls.Add($pb)
    }
    $t = New-Label 'Share Doctor' 20 108 410 34
    $t.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 18)
    $t.TextAlign = 'MiddleCenter'
    $dlg.Controls.Add($t)
    $v = New-Label ('Version ' + $AppVersion) 20 146 410 24
    $v.TextAlign = 'MiddleCenter'; $v.ForeColor = $colGrey
    $dlg.Controls.Add($v)
    $d = New-Label 'Keeps shared folders and printers working across the casino PCs - checks, repairs and reports who connected.' 40 178 370 48
    $d.TextAlign = 'MiddleCenter'
    $dlg.Controls.Add($d)
    $c = New-Label ("Created by Ekin Ozgur`nBuilt with Claude Code") 20 234 410 48
    $c.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10.5)
    $c.TextAlign = 'MiddleCenter'
    $dlg.Controls.Add($c)
    $ok = New-Object System.Windows.Forms.Button
    $ok.Text = 'OK'
    $ok.Location = New-Object System.Drawing.Point(175, 288)
    $ok.Size = New-Object System.Drawing.Size(100, 32)
    $ok.DialogResult = 'OK'
    $dlg.Controls.Add($ok)
    $dlg.AcceptButton = $ok
    [void]$dlg.ShowDialog()
    $dlg.Dispose()
}

function Show-PcPicker([string]$title) {
    $dlg = New-Object System.Windows.Forms.Form
    if ($brandIcon) { $dlg.Icon = $brandIcon }
    $dlg.Text = $title
    $dlg.Size = New-Object System.Drawing.Size(520, 440)
    $dlg.StartPosition = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false; $dlg.MinimizeBox = $false
    $dlg.BackColor = $colBack
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $status = New-Label 'Looking for PCs...' 16 12 470 24
    $dlg.Controls.Add($status)
    $list = New-Object System.Windows.Forms.ListView
    $list.View = 'Details'; $list.CheckBoxes = $true; $list.FullRowSelect = $true
    $list.Location = New-Object System.Drawing.Point(16, 44)
    $list.Size = New-Object System.Drawing.Size(470, 290)
    [void]$list.Columns.Add('PC name', 250)
    [void]$list.Columns.Add('IP address', 180)
    $dlg.Controls.Add($list)
    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text = 'Add the ticked PCs'
    $btnOk.Location = New-Object System.Drawing.Point(250, 350)
    $btnOk.Size = New-Object System.Drawing.Size(150, 36)
    $btnOk.DialogResult = 'OK'
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'Cancel'
    $btnCancel.Location = New-Object System.Drawing.Point(410, 350)
    $btnCancel.Size = New-Object System.Drawing.Size(76, 36)
    $btnCancel.DialogResult = 'Cancel'
    $dlg.Controls.Add($btnOk); $dlg.Controls.Add($btnCancel)
    $script:pickResult = @()
    $dlg.Add_Shown({
        $dlg.Refresh()
        $found = @()
        try { $found = @(Find-Pcs ([string]$cfg.ExpectedSubnet) { param($t) $status.Text = $t; $status.Refresh() }) } catch { Write-Log ('PC scan failed: ' + $_.Exception.Message) }
        foreach ($f in $found) {
            $it = New-Object System.Windows.Forms.ListViewItem($f.Name)
            [void]$it.SubItems.Add($f.IP)
            [void]$list.Items.Add($it)
        }
        if ($found.Count -eq 0) { $status.Text = 'No PCs answered. They may be off, or file sharing is closed on them.' }
        else { $status.Text = ('Found ' + $found.Count + ' PC(s). Tick the ones you want.') }
    })
    if ($dlg.ShowDialog() -eq 'OK') {
        $script:pickResult = @($list.CheckedItems | ForEach-Object { [pscustomobject]@{ Name = $_.Text; IP = $_.SubItems[1].Text } })
    }
    $dlg.Dispose()
    return @($script:pickResult)
}

# ---------------------------------------------------------------- settings window (no Notepad, no commands)
function New-Label($text, $x, $y, $w, $h) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text
    $l.Location = New-Object System.Drawing.Point($x, $y)
    $l.Size = New-Object System.Drawing.Size($w, $h)
    $l.ForeColor = $colText
    return $l
}
function New-Box($x, $y, $w, $text) {
    $t = New-Object System.Windows.Forms.TextBox
    $t.Location = New-Object System.Drawing.Point($x, $y)
    $t.Size = New-Object System.Drawing.Size($w, 26)
    $t.Text = [string]$text
    return $t
}
function New-Grid($headers, $x, $y, $w, $h) {
    $g = New-Object System.Windows.Forms.DataGridView
    $g.Location = New-Object System.Drawing.Point($x, $y)
    $g.Size = New-Object System.Drawing.Size($w, $h)
    $g.AllowUserToAddRows = $true
    $g.AllowUserToDeleteRows = $true
    $g.RowHeadersVisible = $false
    $g.BackgroundColor = [System.Drawing.Color]::White
    $g.BorderStyle = 'FixedSingle'
    $g.AutoSizeColumnsMode = 'Fill'
    foreach ($hd in $headers) { [void]$g.Columns.Add(($hd -replace '\W', ''), $hd) }
    return $g
}
function Get-GridRows($g, [int]$n) {
    $rows = @()
    foreach ($row in $g.Rows) {
        if ($row.IsNewRow) { continue }
        $vals = @()
        for ($i = 0; $i -lt $n; $i++) {
            $v = $row.Cells[$i].Value
            if ($null -eq $v) { $v = '' }
            $vals += ([string]$v).Trim()
        }
        if (($vals -join '') -eq '') { continue }
        $rows += [pscustomobject]@{ V = $vals }
    }
    return $rows
}
function Test-Ipv4([string]$ip) {
    $tmp = $null
    return ($ip -match '^\d{1,3}(\.\d{1,3}){3}$') -and [System.Net.IPAddress]::TryParse($ip, [ref]$tmp)
}

function Show-Settings([bool]$firstRun) {
    $dlg = New-Object System.Windows.Forms.Form
    if ($brandIcon) { $dlg.Icon = $brandIcon }
    $dlg.Text = 'Share Doctor - Settings'
    $dlg.Size = New-Object System.Drawing.Size(740, 620)
    $dlg.StartPosition = 'CenterScreen'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox = $false
    $dlg.BackColor = $colBack
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI', 10)

    $top = 12
    if ($firstRun) {
        $w = New-Label 'Welcome! Fill in what applies to this PC, then click Save. You only do this once on each PC.' 16 12 690 24
        $w.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 11)
        $dlg.Controls.Add($w)
        $top = 44
    }

    $tabs = New-Object System.Windows.Forms.TabControl
    $tabs.Location = New-Object System.Drawing.Point(12, $top)
    $tabs.Size = New-Object System.Drawing.Size(704, 470)

    # --- tab 1: this PC
    $t1 = New-Object System.Windows.Forms.TabPage
    $t1.Text = 'This PC'
    $t1.BackColor = [System.Drawing.Color]::White
    $t1.Controls.Add((New-Label 'Basics for this PC. Every PC can share folders AND open folders from other PCs - use the tabs that apply.' 16 14 660 44))
    $y = 70
    $fields = @(
        @('Router address', 'Gateway'),
        @('Casino network starts with', 'ExpectedSubnet'))
    $boxes = @{}
    foreach ($f in $fields) {
        $t1.Controls.Add((New-Label $f[0] 16 ($y + 3) 270 24))
        $b = New-Box 290 $y 380 $cfg.($f[1])
        $t1.Controls.Add($b)
        $boxes[$f[1]] = $b
        $y += 44
    }
    $t1.Controls.Add((New-Label 'Update source (web address or folder)' 16 ($y + 3) 270 24))
    $txtUpd = New-Box 290 $y 380 ([string]$cfg.UpdateSource)
    $t1.Controls.Add($txtUpd)
    $y += 44
    $t1.Controls.Add((New-Label 'Sharing password (the same on every PC)' 16 ($y + 3) 270 24))
    $txtPw = New-Box 290 $y 380 ''
    $txtPw.UseSystemPasswordChar = $true
    $t1.Controls.Add($txtPw)
    $chkAuto = New-Object System.Windows.Forms.CheckBox
    $chkAuto.Text = 'Find folders that other PCs share with this PC automatically (every 10 minutes)'
    $chkAuto.Location = New-Object System.Drawing.Point(16, ($y + 130))
    $chkAuto.Size = New-Object System.Drawing.Size(660, 28)
    $chkAuto.Checked = ($cfg.AutoDiscover -ne $false)
    $t1.Controls.Add($chkAuto)
    $startLnkPath = Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs\StartUp\Share Doctor.lnk'
    $startWas = (Test-Path -LiteralPath $startLnkPath)
    $chkStart = New-Object System.Windows.Forms.CheckBox
    $chkStart.Text = 'Start Share Doctor when Windows starts'
    $chkStart.Location = New-Object System.Drawing.Point(16, ($y + 160))
    $chkStart.Size = New-Object System.Drawing.Size(400, 28)
    $chkStart.Checked = $startWas
    $t1.Controls.Add($chkStart)
    $btnUpd = New-Object System.Windows.Forms.Button
    $btnUpd.Text = 'Check for updates now'
    $btnUpd.Location = New-Object System.Drawing.Point(430, ($y + 158))
    $btnUpd.Size = New-Object System.Drawing.Size(240, 32)
    $btnUpd.Add_Click({ $cfg.UpdateSource = $txtUpd.Text.Trim(); Check-Update $true })
    $t1.Controls.Add($btnUpd)
    $t1.Controls.Add((New-Label ('Version ' + $AppVersion + ' - created by Ekin Ozgur, built with Claude Code.  Share Doctor creates the sharing account (countshare) on this PC by itself and uses this password to open folders on your other PCs. Use the SAME password on every PC. Leave it empty to keep the current one.') 16 ($y + 50) 660 70))

    # --- tab 2: folders I open from other PCs
    $t2 = New-Object System.Windows.Forms.TabPage
    $t2.Text = 'Folders I open'
    $t2.BackColor = [System.Drawing.Color]::White
    $t2.Controls.Add((New-Label 'Folders on OTHER PCs that this PC opens. Click "Find PCs on the network" to pick them from a list, then "Get the folders of the selected PC" lists what that PC shares. One row per folder. Drive letter is optional (for example Z). The login is filled in for you (PCNAME\countshare).' 16 10 670 50))
    $g2 = New-Grid @('PC name', 'PC IP address', 'Folder name', 'Drive', 'Login on that PC') 16 66 670 300
    foreach ($rm in @($cfg.Remotes)) {
        $shs = @($rm.Shares)
        if ($shs.Count -eq 0) { [void]$g2.Rows.Add([string]$rm.Name, [string]$rm.IP, '', '', [string]$rm.User) }
        foreach ($sh in $shs) { [void]$g2.Rows.Add([string]$rm.Name, [string]$rm.IP, [string]$sh.Share, ([string]$sh.Drive).TrimEnd(':'), [string]$rm.User) }
    }
    $t2.Controls.Add($g2)
    $fillShares = {
        param($row)
        $nm = [string]$row.Cells[0].Value; $ip = [string]$row.Cells[1].Value; $us = [string]$row.Cells[4].Value
        if (-not $ip) { return 'Type the IP address first.' }
        if (-not $us -and $nm) { $us = $nm + '\countshare' }
        $r = Get-RemoteShares $ip $us $txtPw.Text
        if (-not $r.Ok) { return ('Could not read the folders on ' + $ip + ': ' + $r.Error + "`n`nTips: type the sharing password on the 'This PC' tab, and make sure THIS PC is in that PC's 'Who may connect' list.") }
        if ($r.Shares.Count -eq 0) { return ('No shared folders found on ' + $ip + '. Share a folder on that PC first.') }
        $have = @{}
        foreach ($x in $g2.Rows) { if (-not $x.IsNewRow -and [string]$x.Cells[1].Value -eq $ip -and [string]$x.Cells[2].Value) { $have[[string]$x.Cells[2].Value.ToLower()] = $true } }
        $first = $true
        foreach ($sn in $r.Shares) {
            if ($have.ContainsKey($sn.ToLower())) { continue }
            if ($first -and -not [string]$row.Cells[2].Value) { $row.Cells[2].Value = $sn; $first = $false }
            else { [void]$g2.Rows.Add($nm, $ip, $sn, '', $us) }
        }
        return ''
    }
    $btnGet2 = New-Object System.Windows.Forms.Button
    $btnGet2.Text = 'Get the folders of the selected PC'
    $btnGet2.Location = New-Object System.Drawing.Point(270, 372)
    $btnGet2.Size = New-Object System.Drawing.Size(260, 34)
    $btnGet2.Add_Click({
        $row = $g2.CurrentRow
        if (-not $row -or $row.IsNewRow) { [void][System.Windows.Forms.MessageBox]::Show('Click a row first (the PC whose folders you want).', 'Share Doctor'); return }
        $msg = & $fillShares $row
        if ($msg) { [void][System.Windows.Forms.MessageBox]::Show($msg, 'Share Doctor') }
    })
    $t2.Controls.Add($btnGet2)
    $btnFind2 = New-Object System.Windows.Forms.Button
    $btnFind2.Text = 'Find PCs on the network...'
    $btnFind2.Location = New-Object System.Drawing.Point(16, 372)
    $btnFind2.Size = New-Object System.Drawing.Size(240, 34)
    $btnFind2.Add_Click({
        foreach ($pc in (Show-PcPicker 'Find PCs - folders I open')) {
            $nm = [string]$pc.Name; if ($nm -eq '(name not found)') { $nm = '' }
            $us = ''; if ($nm) { $us = $nm + '\countshare' }
            $idx = $g2.Rows.Add($nm, [string]$pc.IP, '', '', $us)
            $msg = & $fillShares $g2.Rows[$idx]
            if ($msg) { Write-Log ('Folder list for ' + $pc.IP + ': ' + ($msg -split "`n")[0]) }
        }
    })
    $t2.Controls.Add($btnFind2)

    # --- tab 3: folders I share
    $t3 = New-Object System.Windows.Forms.TabPage
    $t3.Text = 'Folders I share'
    $t3.BackColor = [System.Drawing.Color]::White
    $t3.Controls.Add((New-Label 'Folders on THIS PC that other PCs may open. Saving creates the share and the sharing account by itself; only that account can open it.' 16 10 670 44))
    $g3 = New-Grid @('Shared as (name)', 'Folder on this PC') 16 60 670 270
    foreach ($ls in @($cfg.LocalShares)) { [void]$g3.Rows.Add([string]$ls.Share, [string]$ls.Path) }
    $t3.Controls.Add($g3)
    $btnMgr = New-Object System.Windows.Forms.Button
    $btnMgr.Text = 'All shares on this PC / remove duplicates...'
    $btnMgr.Location = New-Object System.Drawing.Point(310, 344)
    $btnMgr.Size = New-Object System.Drawing.Size(340, 34)
    $btnMgr.Add_Click({
        $gone = @(Show-ShareManager)
        $haveNames = @{}
        foreach ($row in $g3.Rows) { if (-not $row.IsNewRow) { $haveNames[([string]$row.Cells[0].Value).ToLower()] = $true } }
        foreach ($ad in @($script:adoptShares)) { if (-not $haveNames.ContainsKey(([string]$ad.Share).ToLower())) { [void]$g3.Rows.Add([string]$ad.Share, [string]$ad.Path) } }
        if ($gone.Count -gt 0) {
            $kill = @()
            foreach ($row in $g3.Rows) { if (-not $row.IsNewRow -and ($gone -contains [string]$row.Cells[0].Value)) { $kill += $row } }
            foreach ($row in $kill) { $g3.Rows.Remove($row) }
            if ($kill.Count -gt 0) { [void][System.Windows.Forms.MessageBox]::Show('Those shares were also taken off the list here. Click Save to keep it that way.', 'Share Doctor') }
        }
    })
    $t3.Controls.Add($btnMgr)
    $btnBrowse = New-Object System.Windows.Forms.Button
    $btnBrowse.Text = 'Choose folder for the selected row...'
    $btnBrowse.Location = New-Object System.Drawing.Point(16, 344)
    $btnBrowse.Size = New-Object System.Drawing.Size(280, 34)
    $btnBrowse.Add_Click({
        $fb = New-Object System.Windows.Forms.FolderBrowserDialog
        $fb.Description = 'Choose the folder on this PC that should be shared'
        if ($fb.ShowDialog() -eq 'OK') {
            $row = $g3.CurrentRow
            if (-not $row -or $row.IsNewRow) { $idx = $g3.Rows.Add(); $row = $g3.Rows[$idx] }
            $row.Cells[1].Value = $fb.SelectedPath
            if (-not $row.Cells[0].Value) { $row.Cells[0].Value = (Split-Path $fb.SelectedPath -Leaf) -replace '\s', '' }
        }
    })
    $t3.Controls.Add($btnBrowse)

    # --- tab 4: who may connect to this PC
    $t4 = New-Object System.Windows.Forms.TabPage
    $t4.Text = 'Who may connect'
    $t4.BackColor = [System.Drawing.Color]::White
    $t4.Controls.Add((New-Label 'Only the PCs in this list can open folders on THIS PC. Every other PC is blocked. If this PC shares nothing, leave the list empty: then nobody can reach this PC. Give listed PCs a fixed IP in UniFi.' 16 10 670 60))
    $g4 = New-Grid @('PC name', 'IP address') 16 76 670 250
    foreach ($pc in @($cfg.AllowedPCs)) { [void]$g4.Rows.Add([string]$pc.Name, [string]$pc.IP) }
    $t4.Controls.Add($g4)
    $btnFind4 = New-Object System.Windows.Forms.Button
    $btnFind4.Text = 'Find PCs on the network...'
    $btnFind4.Location = New-Object System.Drawing.Point(16, 376)
    $btnFind4.Size = New-Object System.Drawing.Size(240, 34)
    $btnFind4.Add_Click({
        foreach ($pc in (Show-PcPicker 'Find PCs - who may connect')) {
            $nm = [string]$pc.Name; if ($nm -eq '(name not found)') { $nm = '' }
            [void]$g4.Rows.Add($nm, [string]$pc.IP)
        }
    })
    $t4.Controls.Add($btnFind4)
    $chkBlock = New-Object System.Windows.Forms.CheckBox
    $chkBlock.Text = 'Block PCs that are not allowed (recommended). Untick to turn blocking off.'
    $chkBlock.Location = New-Object System.Drawing.Point(16, 340)
    $chkBlock.Size = New-Object System.Drawing.Size(660, 28)
    $chkBlock.Checked = ($cfg.EnforceAccess -ne $false)
    $t4.Controls.Add($chkBlock)

    # --- tab 5: printers
    $t5 = New-Object System.Windows.Forms.TabPage
    $t5.Text = 'Printers'
    $t5.BackColor = [System.Drawing.Color]::White
    $t5.Controls.Add((New-Label 'Printers Share Doctor watches (status, offline, stuck jobs, and the printer answering on the network). Click "Find printers" to pick from a list. IP address is optional.' 16 10 670 44))
    $g5 = New-Grid @('Printer name', 'IP address (optional)', 'Where it is') 16 60 670 270
    foreach ($pr in @($cfg.Printers)) {
        $srcTxt = [string]$pr.Source
        if (-not $srcTxt) { $srcTxt = 'Network printer' }
        [void]$g5.Rows.Add([string]$pr.Name, [string]$pr.IP, $srcTxt)
    }
    $t5.Controls.Add($g5)
    $btnFindPr = New-Object System.Windows.Forms.Button
    $btnFindPr.Text = 'Find printers...'
    $btnFindPr.Location = New-Object System.Drawing.Point(16, 344)
    $btnFindPr.Size = New-Object System.Drawing.Size(200, 34)
    $btnFindPr.Add_Click({
        $have = @{}
        foreach ($x in $g5.Rows) { if (-not $x.IsNewRow) { $have[([string]$x.Cells[0].Value).ToLower()] = $true } }
        foreach ($pp in (Show-PrinterPicker)) {
            if ($have.ContainsKey(([string]$pp.Name).ToLower())) { continue }
            [void]$g5.Rows.Add([string]$pp.Name, [string]$pp.IP, [string]$pp.Source)
        }
    })
    $t5.Controls.Add($btnFindPr)

    foreach ($tp in @($t1, $t2, $t3, $t4, $t5)) { [void]$tabs.TabPages.Add($tp) }
    $dlg.Controls.Add($tabs)

    $hint = New-Label 'Saving asks Windows for administrator permission once.' 16 ($top + 482) 420 24
    $hint.ForeColor = $colGrey
    $dlg.Controls.Add($hint)

    $btnSave = New-Object System.Windows.Forms.Button
    $btnSave.Text = 'Save'
    $btnSave.Location = New-Object System.Drawing.Point(490, ($top + 476))
    $btnSave.Size = New-Object System.Drawing.Size(110, 36)
    $btnSave.FlatStyle = 'Flat'
    $btnSave.BackColor = $colAccent
    $btnSave.ForeColor = [System.Drawing.Color]::White
    $btnSave.FlatAppearance.BorderSize = 0
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'Cancel'
    $btnCancel.Location = New-Object System.Drawing.Point(610, ($top + 476))
    $btnCancel.Size = New-Object System.Drawing.Size(100, 36)
    $btnCancel.FlatStyle = 'Flat'
    $btnCancel.BackColor = [System.Drawing.Color]::White
    $btnCancel.FlatAppearance.BorderColor = $colLine
    $btnCancel.Add_Click({ $dlg.Close() })
    $dlg.Controls.Add($btnSave); $dlg.Controls.Add($btnCancel)
    $dlg.Size = New-Object System.Drawing.Size(740, ($top + 570))

    $btnSave.Add_Click({
        $remotes = @{}
        $usedDrives = @{}
        foreach ($r in (Get-GridRows $g2 5)) {
            $nm = $r.V[0]; $ip = $r.V[1]; $sh = $r.V[2]; $dr = $r.V[3]; $us = $r.V[4]
            if (-not $nm -or $nm -match '[:,]') { [void][System.Windows.Forms.MessageBox]::Show('Every row in "Folders I open" needs a PC name (no : or , characters).', 'Share Doctor'); return }
            if (-not (Test-Ipv4 $ip)) { [void][System.Windows.Forms.MessageBox]::Show("The IP address for '$nm' does not look right (example: 192.168.10.14).", 'Share Doctor'); return }
            if (-not $us) { $us = $nm + '\countshare' }
            $key = $nm.ToLower()
            if (-not $remotes.ContainsKey($key)) { $remotes[$key] = [pscustomobject]@{ Name = $nm; IP = $ip; User = $us; Shares = @() } }
            if ($sh) {
                $drv = $null
                if ($dr) {
                    $drv = ($dr.Substring(0, 1).ToUpper()) + ':'
                    if ($usedDrives.ContainsKey($drv)) { [void][System.Windows.Forms.MessageBox]::Show("Drive $drv is used twice. Each folder needs its own letter.", 'Share Doctor'); return }
                    $usedDrives[$drv] = $true
                }
                $remotes[$key].Shares += [pscustomobject]@{ Share = $sh; Drive = $drv }
            }
        }
        $local = @()
        foreach ($r in (Get-GridRows $g3 2)) {
            if (-not $r.V[0] -or -not $r.V[1]) { [void][System.Windows.Forms.MessageBox]::Show('Every shared folder needs a name and a folder.', 'Share Doctor'); return }
            if (-not (Test-Path -LiteralPath $r.V[1])) { [void][System.Windows.Forms.MessageBox]::Show(("The folder " + $r.V[1] + " was not found on this PC."), 'Share Doctor'); return }
            $local += [pscustomobject]@{ Share = $r.V[0]; Path = $r.V[1] }
        }
        $allowed = @()
        foreach ($r in (Get-GridRows $g4 2)) {
            if (-not (Test-Ipv4 $r.V[1])) { [void][System.Windows.Forms.MessageBox]::Show(("The IP address for '" + $r.V[0] + "' does not look right."), 'Share Doctor'); return }
            $allowed += [pscustomobject]@{ Name = $r.V[0]; IP = $r.V[1] }
        }
        $printers = @()
        foreach ($r in (Get-GridRows $g5 3)) {
            if ($r.V[1] -and -not (Test-Ipv4 $r.V[1])) { [void][System.Windows.Forms.MessageBox]::Show(("The IP address for printer '" + $r.V[0] + "' does not look right."), 'Share Doctor'); return }
            if (-not $r.V[0]) { [void][System.Windows.Forms.MessageBox]::Show('Every printer row needs a name.', 'Share Doctor'); return }
            $printers += [pscustomobject]@{ Name = $r.V[0]; IP = $r.V[1]; Port = 9100; Source = $r.V[2] }
        }
        if ($local.Count -gt 0 -and $chkBlock.Checked -and $allowed.Count -eq 0) {
            $ans = [System.Windows.Forms.MessageBox]::Show("This PC shares folders but the list of PCs that may connect is empty.`n`nNo other PC will be able to open them. Continue?", 'Share Doctor', 'YesNo', 'Warning')
            if ($ans -ne 'Yes') { return }
        }

        $pwNew = $txtPw.Text
        $new = [pscustomobject]@{
            Gateway = $boxes['Gateway'].Text.Trim(); ExpectedSubnet = $boxes['ExpectedSubnet'].Text.Trim(); ShareUser = ($env:COMPUTERNAME + '\countshare'); SharePassword = $txtPw.Text
            CheckSeconds = [int]$cfg.CheckSeconds; PopupOnFail = [bool]$cfg.PopupOnFail
            EnforceAccess = [bool]$chkBlock.Checked; FirstRun = $false; UpdateSource = $txtUpd.Text.Trim(); AutoDiscover = [bool]$chkAuto.Checked; SharePwProtected = $(if ($pwNew) { ConvertFrom-SecureString (ConvertTo-SecureString $pwNew -AsPlainText -Force) } else { [string]$cfg.SharePwProtected })
            Remotes = @($remotes.Values); LocalShares = @($local); Printers = @($printers); AllowedPCs = @($allowed)
        }
        if ($local.Count -gt 0 -and -not $pwNew -and -not (Get-LocalUser -Name 'countshare' -ErrorAction SilentlyContinue)) {
            [void][System.Windows.Forms.MessageBox]::Show('Please type a sharing password on the "This PC" tab. Share Doctor will create the sharing account with it.', 'Share Doctor'); return
        }
        $tmp = Join-Path $env:TEMP ('sharedoctor-settings-' + [guid]::NewGuid().ToString('N') + '.json')
        $new | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $tmp -Encoding UTF8
        $ok = Start-AdminFix @('ApplyAccess') $tmp
        if ($ok -and $pwNew) {
            Save-UserPassword $pwNew
            foreach ($rm in @($remotes.Values)) {
                foreach ($t in @([string]$rm.Name, [string]$rm.IP)) {
                    [void](Run-Quiet 'cmdkey.exe' ('/delete:"' + $t + '"'))
                    [void](Run-Quiet 'cmdkey.exe' ('/add:"' + $t + '" /user:"' + [string]$rm.User + '" /pass:"' + $pwNew + '"'))
                }
            }
            $cfg = Read-Config
            foreach ($rm in @($cfg.Remotes)) { Fix-Remap ([string]$rm.Name) }
        }
        if ($ok -and ($chkStart.Checked -ne $startWas)) { [void](Start-AdminFix @(('AutoStart:' + $(if ($chkStart.Checked) { '1' } else { '0' })))) }
        if ($ok) { $cfg = Read-Config; Start-Sync }
        if ($ok) {
            [void][System.Windows.Forms.MessageBox]::Show('Saved. Share Doctor will re-check everything now.', 'Share Doctor')
            $dlg.Close()
            Start-Check
        } else {
            Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
            [void][System.Windows.Forms.MessageBox]::Show('Nothing was changed, because administrator permission was not given.', 'Share Doctor')
        }
    })

    [void]$dlg.ShowDialog()
    $dlg.Dispose()
}

# ---------------------------------------------------------------- timers
$pollTimer = New-Object System.Windows.Forms.Timer
$pollTimer.Interval = 500
$pollTimer.Add_Tick({
    try {
        if ($script:running -and $script:async -and $script:async.IsCompleted) {
            try { $script:results = @($script:ps.EndInvoke($script:async)) }
            catch { Write-Log "Check error: $($_.Exception.Message)"; $script:results = @() }
            $script:ps.Dispose()
            $script:running = $false
            Complete-Check
        }
    } catch { Write-Log "Poll error: $($_.Exception.Message)" }
})

$checkTimer = New-Object System.Windows.Forms.Timer
$checkTimer.Interval = [int]$cfg.CheckSeconds * 1000
$checkTimer.Add_Tick({ try { Start-Check } catch { Write-Log "Timer error: $($_.Exception.Message)" } })

$quickTimer = New-Object System.Windows.Forms.Timer
$quickTimer.Interval = 8000
$quickTimer.Add_Tick({ $quickTimer.Stop(); try { Start-Check } catch { } })

$firstTimer = New-Object System.Windows.Forms.Timer
$firstTimer.Interval = 1500
$firstTimer.Add_Tick({ $firstTimer.Stop(); try { if ($cfg.FirstRun) { Show-Settings $true } } catch { Write-Log ('First-run settings error: ' + $_.Exception.Message) } })

$updTimer = New-Object System.Windows.Forms.Timer
$updTimer.Interval = 45000
$updTimer.Add_Tick({ $updTimer.Stop(); try { Check-Update $false } catch { }; $updTimer.Interval = 21600000; $updTimer.Start() })

$syncTimer = New-Object System.Windows.Forms.Timer
$syncTimer.Interval = 15000
$syncTimer.Add_Tick({ $syncTimer.Stop(); try { Start-Sync } catch { Write-Log ('Sync error: ' + $_.Exception.Message) }; $syncTimer.Interval = 600000; $syncTimer.Start() })
$syncPoll = New-Object System.Windows.Forms.Timer
$syncPoll.Interval = 1000
$syncPoll.Add_Tick({ try { if ($script:syncRunning -and $script:syncAsync -and $script:syncAsync.IsCompleted) { Complete-Sync } } catch { Write-Log ('Sync poll error: ' + $_.Exception.Message) } })

$startTimer = New-Object System.Windows.Forms.Timer
$startTimer.Interval = 3000
$startTimer.Add_Tick({ $startTimer.Stop(); try { Start-Check } catch { } })

# ---------------------------------------------------------------- events
$lv.Add_SelectedIndexChanged({
    if ($lv.SelectedItems.Count -gt 0) {
        $r = $lv.SelectedItems[0].Tag
        $t = [string]$r.Detail
        if ($r.Fix) { $t += "`r`n`r`nOne-click fix: " + $FixLabels[(([string]$r.Fix) -split ':')[0]] + "  (use the Fix selected button)" }
        $detail.Text = $t
    }
})

$btnCheck.Add_Click({ $header.Text = 'Checking...'; $sub.Text = ''; Start-Check })
$btnFix.Add_Click({
    if ($lv.SelectedItems.Count -eq 0) { [void][System.Windows.Forms.MessageBox]::Show('Click a row first.', 'Share Doctor'); return }
    $r = $lv.SelectedItems[0].Tag
    if (-not $r.Fix) { [void][System.Windows.Forms.MessageBox]::Show('There is no automatic fix for this one. See the details below the list.', 'Share Doctor'); return }
    Do-Fix @([string]$r.Fix)
})
$btnFixAll.Add_Click({
    $ids = @($script:results | Where-Object { ($_.Status -eq 'FAIL' -or $_.Status -eq 'WARN') -and $_.Fix } | ForEach-Object { [string]$_.Fix })
    if ($ids.Count -eq 0) { [void][System.Windows.Forms.MessageBox]::Show('Nothing to fix automatically.', 'Share Doctor'); return }
    Do-Fix $ids
})
$btnOpen.Add_Click({
    $items = @()
    foreach ($rm in @($cfg.Remotes)) {
        foreach ($sh in @($rm.Shares)) {
            if (-not $sh.Share) { continue }
            $items += [pscustomobject]@{ Text = ([string]$sh.Share + '  -  on ' + $rm.Name); Target = ('\\' + $rm.IP + '\' + $sh.Share) }
        }
    }
    foreach ($ls in @($cfg.LocalShares)) {
        if ($ls.Path) { $items += [pscustomobject]@{ Text = ([string]$ls.Share + '  -  shared from this PC'); Target = [string]$ls.Path } }
    }
    if ($items.Count -eq 0) {
        [void][System.Windows.Forms.MessageBox]::Show('There is no folder to open yet. Open Settings: on "Folders I open", click "Find PCs on the network" and then "Get the folders of the selected PC".', 'Share Doctor')
        return
    }
    if ($items.Count -eq 1) { Start-Process explorer.exe ('"' + $items[0].Target + '"'); return }
    $cm = New-Object System.Windows.Forms.ContextMenuStrip
    foreach ($it in $items) {
        $mi = $cm.Items.Add($it.Text)
        $mi.Tag = $it.Target
        $mi.Add_Click({ param($sender, $e) Start-Process explorer.exe ('"' + [string]$sender.Tag + '"') })
    }
    $cm.Show($btnOpen, (New-Object System.Drawing.Point(0, $btnOpen.Height)))
})
$btnSettings.Add_Click({ try { Show-Settings $false } catch { Write-Log ('Settings error: ' + $_.Exception.Message) } })
$btnLog.Add_Click({
    if (-not $cfg.IsHost) { [void][System.Windows.Forms.MessageBox]::Show('This PC does not share any folders, so there is no activity to show. Open Share Doctor on a PC that shares folders and click Activity there.', 'Share Doctor'); return }
    try { Start-Elevated @('-Activity', '-ConfigPath', $ConfigPath) $false } catch { Write-Log ('Activity window cancelled: ' + $_.Exception.Message) }
})

$notify.Add_DoubleClick({ Show-Window })
$notify.Add_BalloonTipClicked({ Show-Window })
$miOpen.Add_Click({ Show-Window })
$miCheck.Add_Click({ Start-Check })
$miFind.Add_Click({ Start-Sync })
$miUpdate.Add_Click({ Check-Update $true })
$miAbout.Add_Click({ Show-About })
$credit.Add_Click({ Show-About })
$miLog.Add_Click({ if (Test-Path $LogFile) { Start-Process notepad.exe -ArgumentList ('"' + $LogFile + '"') } })
$miSettings.Add_Click({ try { Show-Settings $false } catch { Write-Log ('Settings error: ' + $_.Exception.Message) } })
$miExit.Add_Click({
    $script:exiting = $true
    $notify.Visible = $false
    $notify.Dispose()
    $ctx.ExitThread()
})

$form.Add_Resize({ Resize-Columns })

$form.Add_FormClosing({
    param($sender, $e)
    if (-not $script:exiting) { $e.Cancel = $true; $form.Hide() }
})

# ---------------------------------------------------------------- go
Write-Log ('Share Doctor started. Opens folders from ' + (@($cfg.Remotes | ForEach-Object { $_.Name }) -join ', ') + '; shares ' + @($cfg.LocalShares).Count + ' folder(s)')
$pollTimer.Start()
$checkTimer.Start()
$startTimer.Start()
$firstTimer.Start()
$updTimer.Start()
$syncTimer.Start()
$syncPoll.Start()
[System.Windows.Forms.Application]::Run($ctx)
